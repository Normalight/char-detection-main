"""Qt network I/O is asynchronous; tokens stay in memory only."""
import json
import time

from PySide6.QtCore import QObject, QTimer, QUrl, QSettings, Qt, QEvent, Signal, QSize
from PySide6.QtGui import QShortcut, QIcon, QIconEngine, QPainter, QPainterPath, QPen, QColor, QPixmap
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply, QNetworkInformation
from PySide6.QtWidgets import (
    QApplication, QDialog, QFormLayout, QLineEdit, QLabel, QPushButton,
    QVBoxLayout, QHBoxLayout, QCheckBox, QToolButton, QMessageBox,
)
from .policy import Session, server_url, AUTH_SERVER_URL, uses_encrypted_channel
from .channel import seal_request
from .updates import build_info
from .credentials import CredentialStore


class PasswordEyeIcon(QIconEngine):
    """Resolution-independent eye icon, rendered inside the password field."""
    def __init__(self, crossed=False):
        super().__init__()
        self.crossed = crossed

    def clone(self):
        return PasswordEyeIcon(self.crossed)

    def pixmap(self, size, mode, state):
        # QIconEngine's default surface is not guaranteed to be transparent.
        # Clear it before drawing the outline, including native/high-DPI requests.
        result = QPixmap(size)
        result.fill(Qt.transparent)
        painter = QPainter(result)
        try:
            self.paint(painter, result.rect(), mode, state)
        finally:
            painter.end()
        return result

    def paint(self, painter, rect, mode, state):
        painter.save()
        painter.setRenderHint(QPainter.Antialiasing)
        size = min(rect.width(), rect.height())
        painter.translate(rect.x() + (rect.width() - size) / 2, rect.y() + (rect.height() - size) / 2)
        painter.scale(size / 24, size / 24)
        painter.setPen(QPen(QColor('#829087' if mode == QIcon.Disabled else '#527363'),
                            1.7, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin))
        painter.setBrush(Qt.NoBrush)
        eye = QPainterPath()
        eye.moveTo(2, 12)
        eye.cubicTo(7, 4, 17, 4, 22, 12)
        eye.cubicTo(17, 20, 7, 20, 2, 12)
        painter.drawPath(eye)
        painter.drawEllipse(9, 9, 6, 6)
        if self.crossed:
            painter.drawLine(4, 3, 20, 21)
        painter.restore()


class Transport(QObject):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.manager = QNetworkAccessManager(self)

    def request(self, url, path, callback, token='', body=None):
        url = server_url(url)
        exchange = None
        if uses_encrypted_channel(url):
            body, exchange = seal_request(path, body=body, token=token)
            path, token = '/api/secure', ''
        request = QNetworkRequest(QUrl(url + path))
        request.setTransferTimeout(8000)
        request.setAttribute(QNetworkRequest.RedirectPolicyAttribute, QNetworkRequest.ManualRedirectPolicy)
        request.setHeader(QNetworkRequest.ContentTypeHeader, 'application/json')
        if token:
            request.setRawHeader(b'Authorization', ('Bearer ' + token).encode())
        reply = (self.manager.get(request) if body is None else
                 self.manager.post(request, json.dumps(body).encode()))

        def finished():
            status = reply.attribute(QNetworkRequest.HttpStatusCodeAttribute) or 0
            valid = True
            try:
                data = json.loads(bytes(reply.readAll()))
                if not isinstance(data, dict):
                    raise ValueError()
                if exchange is not None:
                    status, data = exchange.open_response(data)
            except (ValueError, UnicodeError):
                valid = False
                status = 0
                data = {'detail': '服务响应校验失败或无法连接，请检查网络并更新软件。'}
            ok = valid and 200 <= status < 300 and reply.error() == QNetworkReply.NoError
            # Release the reply's closure before deferred deletion. A callback can
            # close the login dialog and destroy this reply's parent manager.
            reply.finished.disconnect(finished)
            reply.deleteLater()
            QTimer.singleShot(0, self, lambda: callback(ok, status, data))
        reply.finished.connect(finished)
        return reply


class LoginDialog(QDialog):

    def __init__(self, product, parent=None, url=None, credential_store=None):
        super().__init__(parent)
        self.product = product
        self.session = None
        self.pending = False
        self.cancelled = False
        self.credential_generation = 0
        self.transport = Transport(self)
        self.settings = QSettings('HanziTools', 'Authentication')
        self.server_url = url or AUTH_SERVER_URL
        self.credentials = credential_store or CredentialStore(self.server_url)
        self.preference = self.credentials.service + '/remember'
        self.username_preference = self.credentials.service + '/username'
        self.setWindowTitle('字霖系列字形处理软件 · 账号登录')
        self.setMinimumWidth(460)
        self.setObjectName('loginDialog')
        self.setStyleSheet("""
            QDialog#loginDialog { background: #f6f5f1; }
            QLabel { color: #24352e; background: transparent; }
            QLabel#brand { color: #64756d; font-size: 12px; }
            QLabel#title { font-size: 27px; font-weight: 600; }

            QLabel#message { color: #a43c32; }
            QLineEdit { background: white; color: #20372c; border: 1px solid #cdd6cf;
                        border-radius: 8px; padding: 11px 12px; font-size: 15px; }
            QLineEdit:focus { border: 2px solid #39795f; padding: 10px 11px; }
            QLineEdit:disabled { color: #829087; background: #eef1ed; }
            QPushButton { background: #246447; color: white; border: none;
                          border-radius: 8px; padding: 13px; font-size: 15px; font-weight: 600; }
            QPushButton:hover { background: #1c533a; }
            QPushButton:disabled { background: #91ac9c; }
            QToolButton { color: #246447; border: none; padding: 0; background: transparent; }
            QCheckBox { color: #475a4e; spacing: 8px; }
        """)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(34, 30, 34, 28)
        layout.setSpacing(12)
        # Brand names follow the product registry inside hanzi-update.
        from .updates import PRODUCT_LABELS
        brand = QLabel('汉字工具  /  ' + PRODUCT_LABELS.get(product, '工作台'))
        brand.setObjectName('brand')
        layout.addWidget(brand)
        title = QLabel('欢迎回来')
        title.setObjectName('title')
        layout.addWidget(title)
        layout.addSpacing(10)
        self.username = QLineEdit(str(self.settings.value(self.username_preference, '')))
        self.username.setPlaceholderText('请输入账号')
        self.username.setClearButtonEnabled(True)
        self.username.setAccessibleName('账号')
        self.password = QLineEdit()
        self.password.setPlaceholderText('请输入密码')
        self.password.setEchoMode(QLineEdit.Password)
        self.password.setAccessibleName('密码')
        layout.addWidget(QLabel('账号'))
        layout.addWidget(self.username)
        layout.addWidget(QLabel('密码'))
        self.show_password = self.password.addAction(QIcon(PasswordEyeIcon()), QLineEdit.TrailingPosition)
        self.show_password.setText('显示密码')
        self.show_password.setToolTip('显示密码')
        self.show_password.setCheckable(True)
        self.show_password.toggled.connect(self.toggle_password)
        for button in self.password.findChildren(QToolButton):
            button.setIconSize(QSize(22, 22))
            button.setAccessibleName('显示密码')
        layout.addWidget(self.password)
        self.remember = QCheckBox('记住密码')
        self.remember.setChecked(self.settings.value(self.preference, True, type=bool))
        layout.addWidget(self.remember)
        self.message = QLabel()
        self.message.setObjectName('message')
        self.message.setTextFormat(Qt.PlainText)
        self.message.setWordWrap(True)
        layout.addWidget(self.message)
        self.message.hide()
        self.submit = QPushButton('登录并进入')
        self.submit.setDefault(True)
        self.submit.clicked.connect(self.login)
        self.username.returnPressed.connect(lambda: self.password.setFocus())
        self.password.returnPressed.connect(self.login)
        layout.addWidget(self.submit)
        self.username.textEdited.connect(self.account_edited)
        self.password.textEdited.connect(self.password_edited)
        self.remember.toggled.connect(self.remember_changed)
        self.setTabOrder(self.username, self.password)
        self.setTabOrder(self.password, self.remember)
        self.setTabOrder(self.remember, self.submit)
        if self.username.text().strip() and self.remember.isChecked():
            self.credential_task('load', self.username.text().strip())
        elif not self.settings.contains(self.username_preference) and self.remember.isChecked():
            # Migrate a legacy account only with credentials for this server.
            # An unrelated server's last username must not appear on first use.
            legacy = str(self.settings.value('username', '')).strip()
            if legacy:
                self.username.setText(legacy)
                self.credential_task('load', legacy)
                if self.password.text():
                    self.settings.setValue(self.username_preference, legacy)
                else:
                    self.username.clear()
                    self.username.setFocus()
        else:
            self.username.setFocus()

    def toggle_password(self, visible):
        self.password.setEchoMode(QLineEdit.Normal if visible else QLineEdit.Password)
        self.show_password.setIcon(QIcon(PasswordEyeIcon(visible)))
        self.show_password.setText('隐藏密码' if visible else '显示密码')
        self.show_password.setToolTip(self.show_password.text())
        for button in self.password.findChildren(QToolButton):
            button.setAccessibleName(self.show_password.text())

    def account_edited(self):
        self.credential_generation += 1
        self.password.clear()

    def password_edited(self):
        self.credential_generation += 1

    def remember_changed(self, checked):
        self.settings.setValue(self.preference, checked)
        self.credential_generation += 1
        if not checked:
            try:
                self.credentials.delete(self.username.text().strip())
            except OSError:
                self.message.setText('无法清除本地保存的密码，请检查文件权限。')
                self.message.show()

    def credential_task(self, operation, username, password=''):
        self.credential_generation += 1
        generation = self.credential_generation
        value, ok = '', True
        try:
            if operation == 'load':
                value = self.credentials.get(username)
            elif operation == 'save':
                self.credentials.set(username, password)
            else:
                self.credentials.delete(username)
        except Exception:
            ok = False
        self.credential_result(generation, operation, value, ok)

    def credential_result(self, generation, operation, value, ok):
        if self.cancelled or generation != self.credential_generation:
            return
        if operation == 'load':
            if ok and value and not self.pending and self.remember.isChecked():
                self.password.setText(value)
                self.submit.setFocus()
            return
        if not ok:
            QMessageBox.information(self, '密码保存', '登录成功，但本地密码文件保存或清除失败，下次可能需要重新输入。')
        self.password.clear()
        self.accept()

    def login(self):
        if self.pending:
            return
        self.message.show()
        try:
            url = server_url(self.server_url)
        except ValueError as exc:
            self.message.setText(str(exc))
            return
        if not self.username.text().strip() or not self.password.text():
            self.message.setText('请输入账号和密码。')
            return
        self.credential_generation += 1
        self.pending = True
        for widget in (self.submit, self.username, self.password, self.remember, self.show_password):
            widget.setEnabled(False)
        self.submit.setText('正在登录…')
        self.message.setText('正在验证账号…')
        self.transport.request(url, '/api/login', lambda ok, status, data: self.result_ready(url, ok, data),
                               body={'username': self.username.text().strip(),
                                     'password': self.password.text(), 'product': self.product,
                                     'client_version': build_info(self.product)['version']})

    def result_ready(self, url, ok, data):
        if self.cancelled:
            return
        self.message.show()
        if ok:
            try:
                self.session = Session.from_login(url, self.product, data)
            except ValueError as exc:
                self.message.setText(str(exc))
            else:
                self.settings.setValue(self.username_preference, self.session.username)
                self.settings.setValue(self.preference, self.remember.isChecked())
                self.message.setText('登录成功，正在准备…')
                self.credential_task('save' if self.remember.isChecked() else 'delete',
                                     self.session.username, self.password.text())
                return
        else:
            detail = data.get('detail')
            self.message.setText(detail if isinstance(detail, str) else '登录失败，请检查输入。')
        self.pending = False
        self.submit.setText('登录并进入')
        for widget in (self.submit, self.username, self.password, self.remember, self.show_password):
            widget.setEnabled(True)

    def reject(self):
        self.cancelled = True
        self.credential_generation += 1
        self.transport.deleteLater()
        self.password.clear()
        super().reject()


class LockDialog(QDialog):
    def reject(self):
        # Keep the recovery controls reachable until login succeeds or app exits.
        pass


class SessionGuard(QObject):
    def __init__(self, window, session, save_callback, lock_callback=None):
        super().__init__(window)
        self.window = window
        self.session = session
        self.save_callback = save_callback
        self.lock_callback = lock_callback
        self.locked = False
        self.inflight = False
        self.next_check = time.monotonic() + session.check_interval
        self.transport = Transport(self)
        QNetworkInformation.loadDefaultBackend()
        self.network = QNetworkInformation.instance()
        if self.network is not None:
            self.network.reachabilityChanged.connect(self.network_changed)
        self.timer = QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self.tick)
        self.timer.start()
        QApplication.instance().installEventFilter(self)

    def eventFilter(self, watched, event):
        # Workers may re-enable shortcuts after completion; intercept dispatch too.
        if event.type() == QEvent.Shortcut and getattr(self, 'locked', False) and isinstance(watched, QShortcut):
            return True
        return False

    def tick(self):
        if self.locked:
            return
        if not self.network_available():
            return
        if not self.inflight and time.monotonic() >= self.next_check:
            self.inflight = True
            self.transport.request(self.session.url, '/api/session', self.checked, self.session.token)

    def network_available(self):
        # Unknown backends fall back to a nonblocking request. Network failures
        # never revoke an already authenticated session.
        return self.network is None or self.network.reachability() in {
            QNetworkInformation.Reachability.Online, QNetworkInformation.Reachability.Unknown}

    def check_native_update(self, target, version, callback):
        """Return availability to the updater without exposing a download URL to its UI."""
        if self.locked:
            callback(False, {})
            return
        body = {'product': self.session.product, 'target': target, 'version': version}
        self.transport.request(self.session.url, '/api/native-update-check',
                               lambda ok, status, data: callback(ok, data if ok else {}),
                               self.session.token, body=body)

    def network_changed(self, reachability):
        if self.network_available():
            self.next_check = 0
            self.tick()

    def checked(self, ok, status, data):
        self.inflight = False
        if self.locked:
            return
        self.next_check = time.monotonic() + self.session.check_interval
        if ok:
            if (data.get('username') != self.session.username or data.get('product') != self.session.product
                    or not isinstance(data.get('expires_at'), int)):
                self.lock('授权响应无效，请重新登录。')
                return
            self.session.last_ok = time.monotonic()
            self.session.expires_at = data['expires_at']
        elif status in (401, 403):
            self.lock('账号已停用、权限已更改或登录已失效。')
        else:
            self.next_check = time.monotonic() + 10

    def lock(self, reason):
        if self.locked:
            return
        self.locked = True
        if self.lock_callback:
            self.lock_callback()
        self.central_was_enabled = self.window.centralWidget().isEnabled()
        self.window.centralWidget().setEnabled(False)
        self.shortcuts = [(s, s.isEnabled()) for s in self.window.findChildren(QShortcut)]
        for shortcut, _ in self.shortcuts:
            shortcut.setEnabled(False)
        self.dialog = LockDialog(self.window)
        self.dialog.setWindowTitle('使用权限已暂停')
        self.dialog.setWindowModality(Qt.ApplicationModal)
        self.dialog.setMinimumWidth(420)
        layout = QVBoxLayout(self.dialog)
        label = QLabel(reason + '\n当前工作仍保留。可以保存当前成果，或重新登录。')
        label.setWordWrap(True)
        layout.addWidget(label)
        save = QPushButton({'char-detection-main': '保存当前页', 'group-by-character': '保存复核结果',
                            'hanzi-mask': '保存采用结果'}.get(self.session.product, '保存当前成果'))
        save.clicked.connect(self.save_callback)
        retry = QPushButton('重新登录')
        retry.clicked.connect(self.relogin)
        layout.addWidget(save)
        layout.addWidget(retry)
        exit_button = QPushButton('退出软件')
        exit_button.clicked.connect(self.exit_window)
        layout.addWidget(exit_button)
        self.dialog.show()

    def exit_window(self):
        self.dialog.hide()
        if not self.window.close():
            self.dialog.show()

    def relogin(self):
        login = LoginDialog(self.session.product, self.dialog, url=self.session.url)
        if login.exec():
            self.session = login.session
            self.locked = False
            self.window.centralWidget().setEnabled(self.central_was_enabled)
            for shortcut, enabled in self.shortcuts:
                shortcut.setEnabled(enabled)
            self.dialog.accept()
            self.dialog.deleteLater()
            self.next_check = time.monotonic() + self.session.check_interval
