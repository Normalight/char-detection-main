"""Small single-host auth service. SQLite holds accounts and revocable sessions."""
import argparse
from contextlib import contextmanager, asynccontextmanager
from collections import OrderedDict
import getpass
import hashlib
import json
import os
from pathlib import Path
import secrets
import sqlite3
import time
import threading
from typing import Literal
from ipaddress import ip_address
from urllib.parse import urlsplit

from argon2 import PasswordHasher
from argon2.exceptions import VerificationError, InvalidHashError
from fastapi import Depends, FastAPI, Header, HTTPException, Request, Query, Response
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel, Field, field_validator, ConfigDict
from starlette.concurrency import run_in_threadpool

PRODUCTS = {"group-by-character", "char-detection-main"}
PH = PasswordHasher()
DUMMY_HASH = PH.hash(secrets.token_urlsafe(32))
SESSION_SECONDS = 12 * 60 * 60
LOGIN_LOG_MAX_ROWS = 10_000
LOGIN_LOG_RETENTION_SECONDS = 30 * 24 * 60 * 60
ADMIN_COOKIE = "hanzi_admin_session"


class LoginLimiter:
    """Bound memory and reject excess traffic before body parsing or SQLite I/O.

    One service process is supported. The reverse proxy adds a separate shared
    ingress limit; don't use multiple workers without a shared limiter.
    """
    def __init__(self, per_ip=60, total=600, max_peers=4096):
        self.per_ip, self.total, self.max_peers = per_ip, total, max_peers
        self.peers = OrderedDict()
        self.started = time.monotonic()
        self.count = 0
        self.lock = threading.Lock()

    def allow(self, address):
        now = time.monotonic()
        with self.lock:
            while self.peers and next(iter(self.peers.values()))[0] <= now - 60:
                self.peers.popitem(last=False)
            started, count = self.peers.get(address, (now, 0))
            if count >= self.per_ip:
                return False
            if address not in self.peers and len(self.peers) >= self.max_peers:
                return False
            if now - self.started >= 60:
                self.started, self.count = now, 0
            if self.count >= self.total:
                return False
            self.peers[address] = (started, count + 1)
            self.count += 1
            return True


class Login(BaseModel):
    username: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_.@-]+$")
    password: str = Field(min_length=1, max_length=256)
    product: str = Field(max_length=64)
    client_version: str = Field(default="", max_length=64)


class NewUser(BaseModel):
    role: Literal["user", "admin"] = "user"
    model_config = ConfigDict(extra="forbid")
    username: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_.@-]+$")
    password: str = Field(min_length=10, max_length=256)
    products: list[str] = Field(default_factory=lambda: sorted(PRODUCTS), max_length=2)
    expires_at: int | None = Field(default=None, gt=0)

    @field_validator("products")
    @classmethod
    def valid_products(cls, values):
        if not set(values) <= PRODUCTS:
            raise ValueError("未知软件权限")
        return sorted(set(values))


class ChangeUser(BaseModel):
    role: Literal["user", "admin"] | None = None
    model_config = ConfigDict(extra="forbid")
    enabled: bool | None = None
    password: str | None = Field(default=None, min_length=10, max_length=256)
    products: list[str] | None = Field(default=None, max_length=2)
    expires_at: int | None = Field(default=None, gt=0)

    @field_validator("products")
    @classmethod
    def valid_products(cls, values):
        return NewUser.valid_products(values) if values is not None else None


class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript('''
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS users (
                    username TEXT PRIMARY KEY, password_hash TEXT NOT NULL,
                    enabled INTEGER NOT NULL DEFAULT 1, admin INTEGER NOT NULL DEFAULT 0,
                    products TEXT NOT NULL, expires_at INTEGER,
                    created_at INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS sessions (
                    token_hash TEXT PRIMARY KEY, username TEXT NOT NULL,
                    product TEXT NOT NULL, expires_at INTEGER NOT NULL,
                    FOREIGN KEY(username) REFERENCES users(username)
                );
                CREATE TABLE IF NOT EXISTS attempts (
                    bucket TEXT PRIMARY KEY, started REAL NOT NULL, count INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS login_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER NOT NULL,
                    username TEXT NOT NULL, product TEXT NOT NULL, ip TEXT NOT NULL,
                    result TEXT NOT NULL, status INTEGER NOT NULL, client_version TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS login_logs_user ON login_logs(username, id);
                CREATE INDEX IF NOT EXISTS login_logs_at ON login_logs(at);
                CREATE TABLE IF NOT EXISTS releases (
                    product TEXT NOT NULL, target TEXT NOT NULL, metadata TEXT NOT NULL,
                    enabled INTEGER NOT NULL, published_at INTEGER NOT NULL,
                    PRIMARY KEY (product, target)
                );
                CREATE TABLE IF NOT EXISTS audit (
                    at INTEGER NOT NULL, actor TEXT NOT NULL,
                    action TEXT NOT NULL, target TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS encrypted_requests (
                    request_id TEXT PRIMARY KEY, expires_at INTEGER NOT NULL
                );
                CREATE INDEX IF NOT EXISTS encrypted_requests_expiry ON encrypted_requests(expires_at);
            ''')
            self.prune_login_logs(db)
        if os.name != "nt":
            self.path.chmod(0o600)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        try:
            with db:
                yield db
        finally:
            db.close()

    def log_login(self, address, status, raw):
        try:
            data = json.loads(raw)
            if not isinstance(data, dict):
                data = {}
        except (ValueError, UnicodeError):
            data = {}
        def field(name):
            value = data.get(name, '')
            return ''.join(c for c in value if c.isprintable())[:64] if isinstance(value, str) else ''
        result = {200: 'success', 401: 'bad_credentials', 403: 'denied', 429: 'rate_limited'}.get(
            status, 'invalid_request' if status < 500 else 'server_error')
        with self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            db.execute('INSERT INTO login_logs(at,username,product,ip,result,status,client_version) VALUES (?,?,?,?,?,?,?)',
                       (int(time.time()), field('username'), field('product'), address[:128],
                        result, status, field('client_version')))
            self.prune_login_logs(db)

    @staticmethod
    def prune_login_logs(db):
        db.execute('DELETE FROM login_logs WHERE at < ?',
                   (int(time.time()) - LOGIN_LOG_RETENTION_SECONDS,))
        db.execute('''DELETE FROM login_logs WHERE id <= (
            SELECT id FROM login_logs ORDER BY id DESC LIMIT 1 OFFSET ?
        )''', (LOGIN_LOG_MAX_ROWS,))

    def create(self, user, admin=False):
        hashed = PH.hash(user.password)
        try:
            with self.connect() as db:
                db.execute("INSERT INTO users VALUES (?, ?, 1, ?, ?, ?, ?)",
                           (user.username, hashed, int(admin), json.dumps(user.products),
                            user.expires_at, int(time.time())))
        except sqlite3.IntegrityError:
            raise HTTPException(409, "账号已存在")


def fingerprint(token):
    return hashlib.sha256(token.encode()).hexdigest()


class ChangeAdminPassword(BaseModel):
    model_config = ConfigDict(extra="forbid")
    current_password: str = Field(min_length=1, max_length=256)
    new_password: str = Field(min_length=10, max_length=256)


def account_role(row):
    if row["admin"] and row["username"] == "admin":
        return "system_admin"
    return "admin" if row["admin"] else "user"


def public_user(row):
    return {"username": row["username"], "enabled": bool(row["enabled"]),
            "admin": bool(row["admin"]), "role": account_role(row), "products": json.loads(row["products"]),
            "expires_at": row["expires_at"], "created_at": row["created_at"]}


def allowed(row, product, now):
    return (row["enabled"] and (row["expires_at"] is None or row["expires_at"] > now)
            and (product == "portal" or (product == "admin" and row["admin"])
                 or (product in PRODUCTS and product in json.loads(row["products"]))))


def browser_origin(value):
    """Compare origins by scheme, host and effective port, never proxy headers."""
    parsed = urlsplit(value)
    if (parsed.scheme not in {'http', 'https'} or not parsed.hostname
            or parsed.username is not None or parsed.password is not None
            or parsed.path not in {'', '/'} or parsed.query or parsed.fragment):
        raise ValueError('公网来源必须为 http(s)://主机[:端口]')
    port = parsed.port
    return parsed.scheme, parsed.hostname, port if port is not None else (443 if parsed.scheme == 'https' else 80)


def create_app(db_path, *, trusted_proxies=(), key_file=None, public_origin=None):
    origin_setting = public_origin if public_origin is not None else os.getenv('HANZI_PUBLIC_ORIGIN', '')
    public_origin = browser_origin(origin_setting) if origin_setting else None
    # Trust only explicitly configured proxy addresses, never arbitrary XFF.
    trusted_proxies = [str(ip_address(value)) for value in trusted_proxies]
    store = Store(db_path)
    login_limiter = LoginLimiter()
    encrypted_limiter = LoginLimiter(per_ip=180, total=1800)
    private_key = None
    if key_file is not None:
        from nacl.public import PrivateKey
        private_key = PrivateKey(Path(key_file).read_bytes())
    from .mirror import Mirror
    mirror = Mirror(store)

    @asynccontextmanager
    async def lifespan(app):
        mirror.start()
        try:
            yield
        finally:
            await run_in_threadpool(mirror.close)

    app = FastAPI(title="汉字工具账号管理", docs_url=None, redoc_url=None, openapi_url=None,
                  lifespan=lifespan)
    app.state.store = store
    app.state.mirror = mirror

    @app.middleware("http")
    async def headers(request, call_next):
        # Also limit bodies before the JSON parser allocates memory.
        raw = b""
        is_login = request.method == "POST" and request.url.path in {"/api/login", "/api/admin/login", "/api/admin/password", "/api/web/login", "/api/web/password"}
        address = request.client.host if request.client else "unknown"
        is_encrypted = request.url.path == '/api/secure'
        if is_encrypted and not encrypted_limiter.allow(address):
            return JSONResponse({'detail': '请求过于频繁，请稍后重试。'}, status_code=429,
                                headers={'Cache-Control': 'no-store', 'Retry-After': '60'})
        if is_login and not login_limiter.allow(address):
            # Deliberately don't persist every rejected request: otherwise the
            # rate limiter itself becomes an unauthenticated disk-write API.
            return JSONResponse({"detail": "登录过于频繁，请一分钟后重试"},
                                status_code=429,
                                headers={"Retry-After": "60", "Cache-Control": "no-store"})
        if request.method in {"POST", "PATCH", "PUT"}:
            total = 0
            chunks = []
            async for chunk in request.stream():
                total += len(chunk)
                if total > (32768 if request.url.path.startswith("/api/admin/updates/") else 8192):
                    if is_login:
                        await run_in_threadpool(store.log_login, address, 413, b"")
                    return JSONResponse({"detail": "请求过大"}, status_code=413)
                chunks.append(chunk)
            raw = request._body = b"".join(chunks)
        try:
            response = await call_next(request)
        except Exception:
            if is_login:
                await run_in_threadpool(store.log_login, address, 500, raw)
            raise
        if is_login:
            await run_in_threadpool(store.log_login, address, response.status_code, raw)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'")
        return response

    @app.post('/api/secure')
    async def encrypted_request(body: dict, request: Request):
        from .channel import open_request, seal_response, CLOCK_SKEW
        if private_key is None:
            raise HTTPException(503, '账号加密服务未配置。')
        try:
            data, exchange, request_id = open_request(body, private_key)
        except ValueError:
            raise HTTPException(400, '加密请求无效或已过期。')
        def claim_request():
            with store.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                db.execute('DELETE FROM encrypted_requests WHERE expires_at < ?', (time.time(),))
                if db.execute('SELECT count(*) FROM encrypted_requests').fetchone()[0] >= 20000:
                    return False
                try:
                    db.execute('INSERT INTO encrypted_requests VALUES (?, ?)',
                               (request_id, data['at'] + CLOCK_SKEW + 1))
                except sqlite3.IntegrityError:
                    return False
            return True
        if not await run_in_threadpool(claim_request):
            return seal_response(exchange, 409, {'detail': '请求已使用或过于频繁，请重试。'})
        allowed_routes = {('POST', '/api/login'), ('GET', '/api/session'),
                          ('POST', '/api/logout'), ('GET', '/health'),
                          ('POST', '/api/native-update-check')}
        route = (data.get('method'), data.get('path'))
        if (not all(isinstance(value, str) for value in route) or route not in allowed_routes
                or (route[1] == '/api/login' and (data.get('body') or {}).get('product') == 'admin')):
            return seal_response(exchange, 403, {'detail': '此入口仅供桌面软件使用。'})
        # Dispatch through the existing validation, auth, logging and limits.
        # This marker is an ASGI scope field, never an HTTP header.
        async def dispatch(scope, receive, send):
            scope['hanzi_encrypted'] = True
            await app(scope, receive, send)
        import httpx
        address = request.client.host if request.client else 'unknown'
        transport = httpx.ASGITransport(app=dispatch, client=(address, 0))
        headers = {'Authorization': 'Bearer ' + data['token']} if data['token'] else {}
        async with httpx.AsyncClient(transport=transport, base_url='http://internal') as client:
            result = await client.request(route[0], route[1], headers=headers, json=data['body'])
        return seal_response(exchange, result.status_code, result.json())

    def secure_cookie(request):
        return ((public_origin is not None and public_origin[0] == 'https')
                or request.url.scheme == "https"
                or os.getenv("HANZI_ADMIN_COOKIE_SECURE", "").lower() in {"1", "true"})

    def browser_request(request):
        # This header requires a CORS preflight from other origins. No CORS origins
        # are enabled here; validate Origin as an additional check when provided.
        if request.headers.get("X-Hanzi-Admin") != "1":
            raise HTTPException(403, "请从管理后台发起操作")
        scheme = "https" if secure_cookie(request) else request.url.scheme
        origin = request.headers.get("origin")
        if origin is not None:
            expected = public_origin or browser_origin(f"{scheme}://{request.url.netloc}")
            try:
                matches = browser_origin(origin) == expected
            except ValueError:
                matches = False
            if not matches:
                raise HTTPException(403, "请求来源不匹配")
        if request.headers.get("sec-fetch-site") == "cross-site":
            raise HTTPException(403, "不允许跨站管理请求")

    def current(request: Request, authorization: str = Header(default="")):
        cookie_auth = not authorization
        if cookie_auth:
            token = request.cookies.get(ADMIN_COOKIE, "")
            if token and request.method not in {"GET", "HEAD", "OPTIONS"}:
                browser_request(request)
            authorization = "Bearer " + token if token else ""
        if not authorization.startswith("Bearer ") or len(authorization) > 256:
            raise HTTPException(401, "请重新登录")
        hashed = fingerprint(authorization[7:])
        now = time.time()
        with store.connect() as db:
            row = db.execute('''SELECT u.*, s.product, s.expires_at AS session_expires
                FROM sessions s JOIN users u ON s.username=u.username
                WHERE s.token_hash=?''', (hashed,)).fetchone()
            if row is None or row["session_expires"] <= now:
                raise HTTPException(401, "登录已失效，请重新登录")
            if cookie_auth and (row["product"] not in {"admin", "portal"} or (row["product"] == "admin" and not row["admin"])):
                raise HTTPException(401, "管理员登录已失效，请重新登录")
            if not allowed(row, row["product"], now):
                raise HTTPException(403, "账号已停用、到期或无此软件权限")
        return row, hashed

    def administrator(session=Depends(current)):
        if not session[0]["admin"] or session[0]["product"] != "admin":
            raise HTTPException(403, "需要管理员权限")
        return session[0]

    @app.get("/", response_class=HTMLResponse)
    def index():
        return Path(__file__).with_name("admin.html").read_text(encoding="utf-8")

    @app.get("/health")
    def health():
        return {"status": "ok"}

    @app.post("/api/login")
    def login(body: Login, request: Request):
        if body.product not in PRODUCTS | {"admin", "portal"}:
            raise HTTPException(400, "未知软件")
        now = time.time()
        address = request.client.host if request.client else "unknown"
        # Count requests before hashing to limit CPU use; no forwarded-IP trust.
        with store.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("DELETE FROM attempts WHERE started < ?", (now - 60,))
            # A remote attacker must not lock an account for unrelated peers.
            for bucket, limit in (("user:" + address + ":" + body.username, 10),):
                row = db.execute("SELECT count FROM attempts WHERE bucket=?", (bucket,)).fetchone()
                if row and row[0] >= limit:
                    raise HTTPException(429, "登录过于频繁，请一分钟后重试")
                db.execute('''INSERT INTO attempts VALUES (?, ?, 1)
                    ON CONFLICT(bucket) DO UPDATE SET count=count+1''', (bucket, now))
        with store.connect() as db:
            user = db.execute("SELECT * FROM users WHERE username=?", (body.username,)).fetchone()
        try:
            PH.verify(user["password_hash"] if user else DUMMY_HASH, body.password)
        except (VerificationError, InvalidHashError):
            raise HTTPException(401, "账号或密码错误")
        if user is None:
            raise HTTPException(401, "账号或密码错误")
        token = secrets.token_urlsafe(32)
        with store.connect() as db:
            # Re-read while holding the write lock: a concurrent password reset
            # or disable must not permit a session from stale credentials.
            db.execute("BEGIN IMMEDIATE")
            latest = db.execute("SELECT * FROM users WHERE username=?", (body.username,)).fetchone()
            if latest["password_hash"] != user["password_hash"]:
                raise HTTPException(401, "密码已更新，请重新登录")
            if not allowed(latest, body.product, now):
                raise HTTPException(403, "账号已停用、到期或无此软件权限")
            deadline = min(int(now) + SESSION_SECONDS, latest["expires_at"] or int(now) + SESSION_SECONDS)
            db.execute("DELETE FROM sessions WHERE expires_at <= ?", (now,))
            db.execute("INSERT INTO sessions VALUES (?, ?, ?, ?)",
                       (fingerprint(token), body.username, body.product, deadline))
        return {"token": token, "username": body.username, "product": body.product,
                "role": account_role(latest),
                "expires_at": deadline, "check_interval": 60, "offline_grace": 300}

    @app.post("/api/admin/login")
    def browser_login(body: Login, request: Request, response: Response):
        browser_request(request)
        if body.product != "admin":
            raise HTTPException(403, "此入口仅供管理员使用")
        data = login(body, request)
        token = data.pop("token")
        previous = request.cookies.get(ADMIN_COOKIE)
        if previous:
            with store.connect() as db:
                db.execute("DELETE FROM sessions WHERE token_hash=? AND product IN ('admin','portal')", (fingerprint(previous),))
        response.set_cookie(ADMIN_COOKIE, token, max_age=max(0, data["expires_at"] - int(time.time())),
                            httponly=True, secure=secure_cookie(request), samesite="strict", path="/api")
        return data

    @app.post("/api/web/login")
    def web_login(body: Login, request: Request, response: Response):
        browser_request(request)
        with store.connect() as db:
            row = db.execute("SELECT admin FROM users WHERE username=?", (body.username,)).fetchone()
        product = "admin" if row and row["admin"] else "portal"
        data = login(body.model_copy(update={"product": product}), request)
        token = data.pop("token")
        previous = request.cookies.get(ADMIN_COOKIE)
        if previous:
            with store.connect() as db:
                db.execute("DELETE FROM sessions WHERE token_hash=? AND product IN ('admin','portal')", (fingerprint(previous),))
        response.set_cookie(ADMIN_COOKIE, token, max_age=max(0, data["expires_at"] - int(time.time())),
                            httponly=True, secure=secure_cookie(request), samesite="strict", path="/api")
        return data

    @app.post("/api/web/logout")
    @app.post("/api/admin/logout")
    def browser_logout(request: Request, response: Response):
        # Also clear expired/revoked cookies, without requiring a valid session.
        browser_request(request)
        token = request.cookies.get(ADMIN_COOKIE, "")
        with store.connect() as db:
            db.execute("DELETE FROM sessions WHERE token_hash=? AND product IN ('admin','portal')", (fingerprint(token),))
        response.delete_cookie(ADMIN_COOKIE, path="/api", httponly=True,
                               secure=secure_cookie(request), samesite="strict")
        return {"ok": True}

    @app.get("/api/session")
    def session_info(session=Depends(current)):
        row = session[0]
        return {"username": row["username"], "product": row["product"],
                "role": account_role(row),
                "expires_at": min(row["session_expires"], row["expires_at"] or row["session_expires"])}

    @app.post("/api/logout")
    def logout(session=Depends(current)):
        with store.connect() as db:
            db.execute("DELETE FROM sessions WHERE token_hash=?", (session[1],))
        return {"ok": True}

    @app.get("/api/admin/users")
    def users(admin=Depends(administrator)):
        with store.connect() as db:
            return [public_user(row) for row in db.execute("SELECT * FROM users ORDER BY created_at, username")]

    @app.post("/api/admin/password")
    def change_admin_password(body: ChangeAdminPassword, request: Request, response: Response,
                              admin=Depends(administrator)):
        return change_password(body, request, response, admin)

    @app.post("/api/web/password")
    def change_web_password(body: ChangeAdminPassword, request: Request, response: Response,
                            session=Depends(current)):
        if session[0]["product"] not in {"portal", "admin"}:
            raise HTTPException(403, "请登录平台后修改密码")
        return change_password(body, request, response, session[0])

    def change_password(body, request, response, admin):
        try:
            PH.verify(admin["password_hash"], body.current_password)
        except (VerificationError, InvalidHashError):
            raise HTTPException(400, "当前密码不正确")
        if body.new_password == body.current_password:
            raise HTTPException(400, "新密码不能与当前密码相同")
        hashed = PH.hash(body.new_password)
        with store.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            latest = db.execute("SELECT * FROM users WHERE username=?", (admin["username"],)).fetchone()
            if latest is None or not allowed(latest, "portal", time.time()) or latest["password_hash"] != admin["password_hash"]:
                raise HTTPException(409, "账号状态已变化，请重新登录")
            db.execute("UPDATE users SET password_hash=? WHERE username=?", (hashed, admin["username"]))
            db.execute("DELETE FROM sessions WHERE username=?", (admin["username"],))
            db.execute("INSERT INTO audit VALUES (?, ?, 'change_password', ?)",
                       (int(time.time()), admin["username"], admin["username"]))
        response.delete_cookie(ADMIN_COOKIE, path="/api", httponly=True,
                               secure=secure_cookie(request), samesite="strict")
        return {"ok": True}

    @app.get('/api/admin/login-logs')
    def login_logs(username: str = Query(default='', max_length=64),
                   result: str = Query(default='', max_length=32),
                   before: int | None = Query(default=None, gt=0),
                   limit: int = Query(default=50, ge=1, le=100), admin=Depends(administrator)):
        clauses, values = [], []
        for key, value in (('username', username), ('result', result)):
            if value:
                clauses.append(key + '=?')
                values.append(value)
        if before is not None:
            clauses.append('id<?')
            values.append(before)
        where = ' WHERE ' + ' AND '.join(clauses) if clauses else ''
        with store.connect() as db:
            rows = db.execute('SELECT * FROM login_logs' + where + ' ORDER BY id DESC LIMIT ?',
                              (*values, limit + 1)).fetchall()
        return {'items': [dict(row) for row in rows[:limit]],
                'next_cursor': rows[limit-1]['id'] if len(rows) > limit else None}

    @app.post("/api/admin/users", status_code=201)
    def add_user(body: NewUser, admin=Depends(administrator)):
        if body.username == "admin":
            raise HTTPException(403, "admin 为保留的系统管理员账号")
        if body.role == "admin" and account_role(admin) != "system_admin":
            raise HTTPException(403, "只有系统管理员可以创建管理员")
        store.create(body, admin=body.role == "admin")
        with store.connect() as db:
            db.execute("INSERT INTO audit VALUES (?, ?, 'create', ?)",
                       (int(time.time()), admin["username"], body.username))
        return {"ok": True}

    @app.patch("/api/admin/users/{username}")
    def update_user(username: str, body: ChangeUser, admin=Depends(administrator)):
        updates = body.model_dump(exclude_unset=True)
        if any(value is None for key, value in updates.items() if key != "expires_at"):
            raise HTTPException(422, "仅有效期可以设为空")
        if "password" in updates:
            updates["password_hash"] = PH.hash(updates.pop("password"))
        if "products" in updates:
            updates["products"] = json.dumps(updates["products"])
        with store.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            target = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
            if target is None:
                raise HTTPException(404, "账号不存在")
            actor = db.execute("SELECT * FROM users WHERE username=?", (admin["username"],)).fetchone()
            if actor is None or not allowed(actor, "admin", time.time()):
                raise HTTPException(403, "需要管理员权限")
            if account_role(target) == "system_admin":
                raise HTTPException(403, "系统管理员请通过修改密码入口维护本人密码")
            if account_role(actor) != "system_admin" and (target["admin"] or updates.get("role") == "admin"):
                raise HTTPException(403, "只有系统管理员可以管理管理员账号")
            if "role" in updates:
                updates["admin"] = int(updates.pop("role") == "admin")
            if updates:
                assignments = ", ".join(key + "=?" for key in updates)
                db.execute(f"UPDATE users SET {assignments} WHERE username=?", (*updates.values(), username))
                db.execute("DELETE FROM sessions WHERE username=?", (username,))
                db.execute("INSERT INTO audit VALUES (?, ?, ?, ?)",
                           (int(time.time()), admin["username"], "update:" + ",".join(sorted(updates)), username))
        return {"ok": True}

    from .update_api import add_routes
    add_routes(app, store, current, administrator)
    from .mirror_api import add_routes as add_mirror_routes
    add_mirror_routes(app, mirror, administrator)
    if trusted_proxies:
        from uvicorn.middleware.proxy_headers import ProxyHeadersMiddleware
        app.add_middleware(ProxyHeadersMiddleware, trusted_hosts=trusted_proxies)
    return app


def main():
    parser = argparse.ArgumentParser(description="汉字工具账号服务")
    parser.add_argument("--db", default="data/accounts.sqlite3")
    sub = parser.add_subparsers(dest="command", required=True)
    initialize = sub.add_parser("init-admin", help="创建管理员（密码交互输入）")
    initialize.add_argument("--username", default="admin")
    reset = sub.add_parser("reset-admin", help="重置已有管理员密码并撤销会话")
    reset.add_argument("--username", default="admin")
    serve = sub.add_parser("serve")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8765)
    serve.add_argument("--trusted-proxy", action="append", default=[],
                       help="可信反向代理的单个 IP，可重复指定；代理必须覆盖来源头")
    serve.add_argument('--key-file', help='桌面通信私钥文件，仅保存在服务器')
    serve.add_argument('--public-origin', help='可信公网来源，例如 https://platform.myhanzi.cn；也可设置 HANZI_PUBLIC_ORIGIN')
    args = parser.parse_args()
    if args.command in {"init-admin", "reset-admin"}:
        password = getpass.getpass("管理员密码（至少10位）：")
        if password != getpass.getpass("再次输入："):
            parser.error("两次密码不一致")
        user = NewUser(username=args.username, password=password)
        store = Store(args.db)
        if args.command == "init-admin":
            store.create(user, admin=True)
        else:
            with store.connect() as db:
                row = db.execute("SELECT admin FROM users WHERE username=?", (args.username,)).fetchone()
                if not row or not row[0]:
                    parser.error("管理员不存在")
                db.execute("UPDATE users SET password_hash=?, enabled=1, expires_at=NULL WHERE username=?",
                           (PH.hash(password), args.username))
                db.execute("DELETE FROM sessions WHERE username=?", (args.username,))
        print("管理员已更新。")
    else:
        import uvicorn
        uvicorn.run(create_app(args.db, trusted_proxies=args.trusted_proxy, key_file=args.key_file,
                               public_origin=args.public_origin),
                    host=args.host, port=args.port, proxy_headers=False, access_log=False)


if __name__ == "__main__":
    main()
