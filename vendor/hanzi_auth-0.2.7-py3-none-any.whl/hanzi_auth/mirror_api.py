"""Administrator-only mirror controls; credentials are write-only."""
import time
from fastapi import Depends, HTTPException
from pydantic import BaseModel, Field
from .mirror_http import MirrorError


class Settings(BaseModel):
    enabled: bool
    github_token: str = Field(default='', max_length=1024)
    gitcode_token: str = Field(default='', max_length=1024)
    download_accelerator: str | None = Field(default=None, max_length=1024)


def add_routes(app, mirror, administrator):
    @app.get('/api/admin/release-mirror')
    def status(admin=Depends(administrator)):
        try:
            return mirror.snapshot()
        except MirrorError as exc:
            raise HTTPException(422, str(exc))

    @app.put('/api/admin/release-mirror')
    def configure(body: Settings, admin=Depends(administrator)):
        try:
            mirror.configure(body.enabled, body.github_token, body.gitcode_token, body.download_accelerator)
        except (MirrorError, ValueError, OSError):
            raise HTTPException(422, '无法保存，请检查同步配置和服务器目录权限') from None
        with mirror.store.connect() as db:
            db.execute("INSERT INTO audit VALUES (?, ?, 'configure_mirror', ?)",
                       (int(time.time()), admin['username'], 'enabled' if body.enabled else 'disabled'))
        return {'ok': True}

    @app.post('/api/admin/release-mirror/check', status_code=202)
    def check(admin=Depends(administrator)):
        accepted = mirror.trigger()
        return {'accepted': accepted}
