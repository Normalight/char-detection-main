"""WinSparkle C ABI. No downloading, verification or installation in Python."""
import ctypes


class WindowsUpdater:
    def __init__(self, config, location, prepare, shutdown, event, loader=ctypes.CDLL):
        self.config = config
        self.dll = loader(str(location / 'WinSparkle.dll'))
        self.callbacks = []
        self.active = False
        self.prepare, self.request_shutdown, self.event = prepare, shutdown, event

    def bind(self, name, args=(), result=None):
        fn = getattr(self.dll, 'win_sparkle_' + name)
        fn.argtypes, fn.restype = list(args), result
        return fn

    def callback(self, name, function, result=None):
        kind = ctypes.CFUNCTYPE(result)
        callback = kind(function)
        self.callbacks.append(callback)  # Keep callbacks alive until cleanup joins workers.
        self.bind('set_' + name + '_callback', [kind])(callback)

    def initialize(self):
        if self.active:
            return
        c = self.config
        self.bind('set_appcast_url', [ctypes.c_char_p])(c.feed_url.encode())
        self.bind('set_lang', [ctypes.c_char_p])(b'zh-CN')
        if self.bind('set_eddsa_public_key', [ctypes.c_char_p], ctypes.c_int)(c.public_key.encode()) != 1:
            raise ValueError('WinSparkle 拒绝更新公钥')
        self.bind('set_app_details', [ctypes.c_wchar_p] * 3)('Hanzi', c.product, c.version.removeprefix('v'))
        self.bind('set_app_build_version', [ctypes.c_wchar_p])(c.build_version)
        self.callback('can_shutdown', self.prepare, ctypes.c_int)
        self.callback('shutdown_request', self.request_shutdown)
        self.callback('error', lambda: self.event('update_error'))
        self.callback('did_find_update', lambda: self.event('update_found'))
        def installer_ready(_path):
            self.event('download_finished')
            self.event('installer_requested')
            return 0  # Let WinSparkle execute the verified installer.
        kind = ctypes.CFUNCTYPE(ctypes.c_int, ctypes.c_wchar_p)
        callback = kind(installer_ready)
        self.callbacks.append(callback)
        self.bind('set_user_run_installer_callback', [kind])(callback)
        self.bind('set_automatic_check_for_updates', [ctypes.c_int])(0)
        self.bind('init')()
        self.active = True

    def check_for_updates(self, *, manual=True):
        if self.active:
            self.event('check_started')
            self.bind('check_update_with_ui' if manual else 'check_update_without_ui')()

    def shutdown(self):
        if self.active:
            self.bind('cleanup')()
            self.active = False
