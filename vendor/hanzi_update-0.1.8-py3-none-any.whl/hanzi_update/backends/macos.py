"""Thin Sparkle bridge wrapper, targeting the outer product bundle."""
import ctypes
import re


class MacUpdater:
    def __init__(self, config, location, prepare, shutdown, event, loader=ctypes.CDLL):
        self.config = config
        self.location = location
        self.dll = loader(str(location / 'Contents/Frameworks/SparkleBridge.dylib'))
        self.prepare = ctypes.CFUNCTYPE(None)(prepare)
        def report(name, version):
            name = (name or b'').decode('ascii', errors='ignore')
            version = re.sub(r'[^0-9A-Za-z.+-]', '', (version or b'').decode('ascii', errors='ignore'))[:64]
            event(name + (' target_version=' + version if version else ''))
        self.report = ctypes.CFUNCTYPE(None, ctypes.c_char_p, ctypes.c_char_p)(report)
        self.active = False
        self.event = event
        self.dll.sparkle_initialize.argtypes = [ctypes.c_char_p, type(self.prepare), type(self.report)]
        self.dll.sparkle_initialize.restype = ctypes.c_int
        for name in ('sparkle_check_for_updates', 'sparkle_check_for_updates_in_background',
                     'sparkle_resume_installation', 'sparkle_shutdown'):
            getattr(self.dll, name).argtypes = []
            getattr(self.dll, name).restype = None

    def initialize(self):
        if not self.active:
            if not self.dll.sparkle_initialize(str(self.location).encode(), self.prepare, self.report):
                raise RuntimeError('Sparkle 初始化失败')
            self.active = True

    def check_for_updates(self, *, manual=True):
        if self.active:
            self.event('check_started')
            if manual:
                self.dll.sparkle_check_for_updates()
            else:
                self.dll.sparkle_check_for_updates_in_background()

    def resume_installation(self):
        self.dll.sparkle_resume_installation()

    def shutdown(self):
        if self.active:
            self.dll.sparkle_shutdown()
            self.active = False
