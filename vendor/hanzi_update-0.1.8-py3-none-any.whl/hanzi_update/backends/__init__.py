"""Platform selection is confined to this factory."""
import sys


def create_updater(config, location, *, prepare, shutdown, event):
    if sys.platform == 'win32':
        from .windows import WindowsUpdater
        return WindowsUpdater(config, location, prepare, shutdown, event)
    if sys.platform == 'darwin':
        from .macos import MacUpdater
        return MacUpdater(config, location, prepare, shutdown, event)
    raise RuntimeError('当前平台不支持原生更新')
