"""Per-user, per-product instance ownership shared by all installed versions."""
import hashlib
from pathlib import Path

from PySide6.QtCore import QLockFile, QStandardPaths
from PySide6.QtNetwork import QLocalServer, QLocalSocket
from PySide6.QtWidgets import QApplication

from .updates import PRODUCTS


class SingleInstance:
    def __init__(self, product, directory=None):
        if product not in PRODUCTS:
            raise ValueError('Unknown desktop product')
        directory = Path(directory or QStandardPaths.writableLocation(QStandardPaths.GenericDataLocation)) / 'HanziTools' / 'locks'
        directory.mkdir(parents=True, exist_ok=True)
        self.lock = QLockFile(str(directory / (product + '.lock')))
        # Live OCR jobs may take hours. Only a dead owner's lock is stale.
        self.lock.setStaleLockTime(0)
        self.name = 'hanzi-' + hashlib.sha256(str(directory.resolve() / product).encode()).hexdigest()[:32]
        self.server = None
        self.window = None

    def acquire(self):
        if not self.lock.tryLock(0):
            if self.lock.error() != QLockFile.LockFailedError:
                raise RuntimeError('无法创建软件运行锁，请检查用户目录权限。')
            socket = QLocalSocket()
            socket.connectToServer(self.name)
            socket.waitForConnected(1000)
            socket.disconnectFromServer()
            return False
        QLocalServer.removeServer(self.name)
        self.server = QLocalServer()
        self.server.setSocketOptions(QLocalServer.UserAccessOption)
        self.server.newConnection.connect(self.activate)
        if not self.server.listen(self.name):
            self.lock.unlock()
            raise RuntimeError('无法启动软件实例通信，请稍后重试。')
        return True

    def activate(self):
        while self.server.hasPendingConnections():
            socket = self.server.nextPendingConnection()
            socket.disconnectFromServer()
            socket.deleteLater()
        window = QApplication.activeModalWidget() or self.window
        if window is None:
            window = next((w for w in QApplication.topLevelWidgets() if w.isVisible()), None)
        if window is not None:
            if window.isMinimized():
                window.showNormal()
            window.raise_()
            window.activateWindow()

    def close(self):
        if self.server is not None:
            self.server.close()
            self.server = None
        self.lock.unlock()


def acquire_instance(app, product):
    instance = SingleInstance(product)
    if not instance.acquire():
        return None
    # Keep the lock until process teardown, after all save/worker cleanup.
    app._hanzi_instance = instance
    return instance
