"""Small single-host auth service. SQLite holds accounts and revocable sessions."""
import argparse
from contextlib import contextmanager
import getpass
import hashlib
import json
import os
from pathlib import Path
import secrets
import sqlite3
import time

from argon2 import PasswordHasher
from argon2.exceptions import VerificationError, InvalidHashError
from fastapi import Depends, FastAPI, Header, HTTPException, Request, Query
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field, field_validator
from starlette.concurrency import run_in_threadpool

PRODUCTS = {"group-by-character", "char-detection-main"}
PH = PasswordHasher()
DUMMY_HASH = PH.hash(secrets.token_urlsafe(32))
SESSION_SECONDS = 12 * 60 * 60


class Login(BaseModel):
    username: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_.@-]+$")
    password: str = Field(min_length=1, max_length=256)
    product: str = Field(max_length=64)
    client_version: str = Field(default="", max_length=64)


class NewUser(BaseModel):
    username: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_.@-]+$")
    password: str = Field(min_length=10, max_length=256)
    products: list[str] = Field(default_factory=lambda: sorted(PRODUCTS), max_length=2)
    expires_at: int | None = Field(default=None, gt=0)

    @field_validator("products")
    @classmethod
    def valid_products(cls, values):
        if not set(values) <= PRODUCTS:
            raise ValueError("未知软件权限")
        return sorted(set(values))


class ChangeUser(BaseModel):
    enabled: bool | None = None
    password: str | None = Field(default=None, min_length=10, max_length=256)
    products: list[str] | None = Field(default=None, max_length=2)
    expires_at: int | None = Field(default=None, gt=0)

    @field_validator("products")
    @classmethod
    def valid_products(cls, values):
        return NewUser.valid_products(values) if values is not None else None


class Store:
    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self.connect() as db:
            db.executescript('''
                PRAGMA journal_mode=WAL;
                CREATE TABLE IF NOT EXISTS users (
                    username TEXT PRIMARY KEY, password_hash TEXT NOT NULL,
                    enabled INTEGER NOT NULL DEFAULT 1, admin INTEGER NOT NULL DEFAULT 0,
                    products TEXT NOT NULL, expires_at INTEGER,
                    created_at INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS sessions (
                    token_hash TEXT PRIMARY KEY, username TEXT NOT NULL,
                    product TEXT NOT NULL, expires_at INTEGER NOT NULL,
                    FOREIGN KEY(username) REFERENCES users(username)
                );
                CREATE TABLE IF NOT EXISTS attempts (
                    bucket TEXT PRIMARY KEY, started REAL NOT NULL, count INTEGER NOT NULL
                );
                CREATE TABLE IF NOT EXISTS login_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, at INTEGER NOT NULL,
                    username TEXT NOT NULL, product TEXT NOT NULL, ip TEXT NOT NULL,
                    result TEXT NOT NULL, status INTEGER NOT NULL, client_version TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS login_logs_user ON login_logs(username, id);
                CREATE TABLE IF NOT EXISTS releases (
                    product TEXT NOT NULL, target TEXT NOT NULL, metadata TEXT NOT NULL,
                    enabled INTEGER NOT NULL, published_at INTEGER NOT NULL,
                    PRIMARY KEY (product, target)
                );
                CREATE TABLE IF NOT EXISTS audit (
                    at INTEGER NOT NULL, actor TEXT NOT NULL,
                    action TEXT NOT NULL, target TEXT NOT NULL
                );
            ''')
        if os.name != "nt":
            self.path.chmod(0o600)

    @contextmanager
    def connect(self):
        db = sqlite3.connect(self.path, timeout=15)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        try:
            with db:
                yield db
        finally:
            db.close()

    def log_login(self, address, status, raw):
        try:
            data = json.loads(raw)
            if not isinstance(data, dict):
                data = {}
        except (ValueError, UnicodeError):
            data = {}
        def field(name):
            value = data.get(name, '')
            return ''.join(c for c in value if c.isprintable())[:64] if isinstance(value, str) else ''
        result = {200: 'success', 401: 'bad_credentials', 403: 'denied', 429: 'rate_limited'}.get(
            status, 'invalid_request' if status < 500 else 'server_error')
        with self.connect() as db:
            db.execute('INSERT INTO login_logs(at,username,product,ip,result,status,client_version) VALUES (?,?,?,?,?,?,?)',
                       (int(time.time()), field('username'), field('product'), address[:128],
                        result, status, field('client_version')))

    def create(self, user, admin=False):
        hashed = PH.hash(user.password)
        try:
            with self.connect() as db:
                db.execute("INSERT INTO users VALUES (?, ?, 1, ?, ?, ?, ?)",
                           (user.username, hashed, int(admin), json.dumps(user.products),
                            user.expires_at, int(time.time())))
        except sqlite3.IntegrityError:
            raise HTTPException(409, "账号已存在")


def fingerprint(token):
    return hashlib.sha256(token.encode()).hexdigest()


def public_user(row):
    return {"username": row["username"], "enabled": bool(row["enabled"]),
            "admin": bool(row["admin"]), "products": json.loads(row["products"]),
            "expires_at": row["expires_at"], "created_at": row["created_at"]}


def allowed(row, product, now):
    return (row["enabled"] and (row["expires_at"] is None or row["expires_at"] > now)
            and ((product == "admin" and row["admin"])
                 or (product in PRODUCTS and product in json.loads(row["products"]))))


def create_app(db_path):
    store = Store(db_path)
    app = FastAPI(title="汉字工具账号管理", docs_url=None, redoc_url=None, openapi_url=None)
    app.state.store = store

    @app.middleware("http")
    async def headers(request, call_next):
        # Also limit bodies before the JSON parser allocates memory.
        raw = b""
        is_login = request.method == "POST" and request.url.path == "/api/login"
        address = request.client.host if request.client else "unknown"
        if request.method in {"POST", "PATCH", "PUT"}:
            total = 0
            chunks = []
            async for chunk in request.stream():
                total += len(chunk)
                if total > (32768 if request.url.path.startswith("/api/admin/updates/") else 8192):
                    from fastapi.responses import JSONResponse
                    if is_login:
                        await run_in_threadpool(store.log_login, address, 413, b"")
                    return JSONResponse({"detail": "请求过大"}, status_code=413)
                chunks.append(chunk)
            raw = request._body = b"".join(chunks)
        try:
            response = await call_next(request)
        except Exception:
            if is_login:
                await run_in_threadpool(store.log_login, address, 500, raw)
            raise
        if is_login:
            await run_in_threadpool(store.log_login, address, response.status_code, raw)
        response.headers["Cache-Control"] = "no-store"
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'self' 'unsafe-inline'; "
            "style-src 'self' 'unsafe-inline'; frame-ancestors 'none'; base-uri 'none'")
        return response

    def current(authorization: str = Header(default="")):
        if not authorization.startswith("Bearer ") or len(authorization) > 256:
            raise HTTPException(401, "请重新登录")
        hashed = fingerprint(authorization[7:])
        now = time.time()
        with store.connect() as db:
            row = db.execute('''SELECT u.*, s.product, s.expires_at AS session_expires
                FROM sessions s JOIN users u ON s.username=u.username
                WHERE s.token_hash=?''', (hashed,)).fetchone()
            if row is None or row["session_expires"] <= now:
                raise HTTPException(401, "登录已失效，请重新登录")
            if not allowed(row, row["product"], now):
                raise HTTPException(403, "账号已停用、到期或无此软件权限")
        return row, hashed

    def administrator(session=Depends(current)):
        if not session[0]["admin"] or session[0]["product"] != "admin":
            raise HTTPException(403, "需要管理员权限")
        return session[0]

    @app.get("/", response_class=HTMLResponse)
    def index():
        return Path(__file__).with_name("admin.html").read_text(encoding="utf-8")

    @app.get("/health")
    def health():
        return {"status": "ok"}

    @app.post("/api/login")
    def login(body: Login, request: Request):
        if body.product not in PRODUCTS | {"admin"}:
            raise HTTPException(400, "未知软件")
        now = time.time()
        address = request.client.host if request.client else "unknown"
        # Count requests before hashing to limit CPU use; no forwarded-IP trust.
        with store.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            db.execute("DELETE FROM attempts WHERE started < ?", (now - 60,))
            for bucket, limit in (("ip:" + address, 60), ("user:" + body.username, 10)):
                row = db.execute("SELECT count FROM attempts WHERE bucket=?", (bucket,)).fetchone()
                if row and row[0] >= limit:
                    raise HTTPException(429, "登录过于频繁，请一分钟后重试")
                db.execute('''INSERT INTO attempts VALUES (?, ?, 1)
                    ON CONFLICT(bucket) DO UPDATE SET count=count+1''', (bucket, now))
        with store.connect() as db:
            user = db.execute("SELECT * FROM users WHERE username=?", (body.username,)).fetchone()
        try:
            PH.verify(user["password_hash"] if user else DUMMY_HASH, body.password)
        except (VerificationError, InvalidHashError):
            raise HTTPException(401, "账号或密码错误")
        if user is None:
            raise HTTPException(401, "账号或密码错误")
        token = secrets.token_urlsafe(32)
        with store.connect() as db:
            # Re-read while holding the write lock: a concurrent password reset
            # or disable must not permit a session from stale credentials.
            db.execute("BEGIN IMMEDIATE")
            latest = db.execute("SELECT * FROM users WHERE username=?", (body.username,)).fetchone()
            if latest["password_hash"] != user["password_hash"]:
                raise HTTPException(401, "密码已更新，请重新登录")
            if not allowed(latest, body.product, now):
                raise HTTPException(403, "账号已停用、到期或无此软件权限")
            deadline = min(int(now) + SESSION_SECONDS, latest["expires_at"] or int(now) + SESSION_SECONDS)
            db.execute("DELETE FROM sessions WHERE expires_at <= ?", (now,))
            db.execute("INSERT INTO sessions VALUES (?, ?, ?, ?)",
                       (fingerprint(token), body.username, body.product, deadline))
        return {"token": token, "username": body.username, "product": body.product,
                "expires_at": deadline, "check_interval": 60, "offline_grace": 300}

    @app.get("/api/session")
    def session_info(session=Depends(current)):
        row = session[0]
        return {"username": row["username"], "product": row["product"],
                "expires_at": min(row["session_expires"], row["expires_at"] or row["session_expires"])}

    @app.post("/api/logout")
    def logout(session=Depends(current)):
        with store.connect() as db:
            db.execute("DELETE FROM sessions WHERE token_hash=?", (session[1],))
        return {"ok": True}

    @app.get("/api/admin/users")
    def users(admin=Depends(administrator)):
        with store.connect() as db:
            return [public_user(row) for row in db.execute("SELECT * FROM users ORDER BY created_at, username")]

    @app.get('/api/admin/login-logs')
    def login_logs(username: str = Query(default='', max_length=64),
                   result: str = Query(default='', max_length=32),
                   before: int | None = Query(default=None, gt=0),
                   limit: int = Query(default=50, ge=1, le=100), admin=Depends(administrator)):
        clauses, values = [], []
        for key, value in (('username', username), ('result', result)):
            if value:
                clauses.append(key + '=?')
                values.append(value)
        if before is not None:
            clauses.append('id<?')
            values.append(before)
        where = ' WHERE ' + ' AND '.join(clauses) if clauses else ''
        with store.connect() as db:
            rows = db.execute('SELECT * FROM login_logs' + where + ' ORDER BY id DESC LIMIT ?',
                              (*values, limit + 1)).fetchall()
        return {'items': [dict(row) for row in rows[:limit]],
                'next_cursor': rows[limit-1]['id'] if len(rows) > limit else None}

    @app.post("/api/admin/users", status_code=201)
    def add_user(body: NewUser, admin=Depends(administrator)):
        store.create(body)
        with store.connect() as db:
            db.execute("INSERT INTO audit VALUES (?, ?, 'create', ?)",
                       (int(time.time()), admin["username"], body.username))
        return {"ok": True}

    @app.patch("/api/admin/users/{username}")
    def update_user(username: str, body: ChangeUser, admin=Depends(administrator)):
        updates = body.model_dump(exclude_unset=True)
        if any(value is None for key, value in updates.items() if key != "expires_at"):
            raise HTTPException(422, "仅有效期可以设为空")
        if "password" in updates:
            updates["password_hash"] = PH.hash(updates.pop("password"))
        if "products" in updates:
            updates["products"] = json.dumps(updates["products"])
        with store.connect() as db:
            db.execute("BEGIN IMMEDIATE")
            target = db.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
            if target is None:
                raise HTTPException(404, "账号不存在")
            if target["admin"]:
                raise HTTPException(403, "管理员账号请使用服务器命令维护")
            if updates:
                assignments = ", ".join(key + "=?" for key in updates)
                db.execute(f"UPDATE users SET {assignments} WHERE username=?", (*updates.values(), username))
                db.execute("DELETE FROM sessions WHERE username=?", (username,))
                db.execute("INSERT INTO audit VALUES (?, ?, ?, ?)",
                           (int(time.time()), admin["username"], "update:" + ",".join(sorted(updates)), username))
        return {"ok": True}

    from .update_api import add_routes
    add_routes(app, store, current, administrator)
    return app


def main():
    parser = argparse.ArgumentParser(description="汉字工具账号服务")
    parser.add_argument("--db", default="data/accounts.sqlite3")
    sub = parser.add_subparsers(dest="command", required=True)
    initialize = sub.add_parser("init-admin", help="创建管理员（密码交互输入）")
    initialize.add_argument("--username", default="admin")
    reset = sub.add_parser("reset-admin", help="重置已有管理员密码并撤销会话")
    reset.add_argument("--username", default="admin")
    serve = sub.add_parser("serve")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    if args.command in {"init-admin", "reset-admin"}:
        password = getpass.getpass("管理员密码（至少10位）：")
        if password != getpass.getpass("再次输入："):
            parser.error("两次密码不一致")
        user = NewUser(username=args.username, password=password)
        store = Store(args.db)
        if args.command == "init-admin":
            store.create(user, admin=True)
        else:
            with store.connect() as db:
                row = db.execute("SELECT admin FROM users WHERE username=?", (args.username,)).fetchone()
                if not row or not row[0]:
                    parser.error("管理员不存在")
                db.execute("UPDATE users SET password_hash=?, enabled=1, expires_at=NULL WHERE username=?",
                           (PH.hash(password), args.username))
                db.execute("DELETE FROM sessions WHERE username=?", (args.username,))
        print("管理员已更新。")
    else:
        import uvicorn
        uvicorn.run(create_app(args.db), host=args.host, port=args.port, proxy_headers=False)


if __name__ == "__main__":
    main()
