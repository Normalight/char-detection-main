"""Nonblocking desktop update UI shared by both products."""
import os
from pathlib import Path
import subprocess
import sys
import threading
from urllib.parse import quote

from PySide6.QtCore import QObject, QTimer, Qt, Signal, QStandardPaths, QUrl
from PySide6.QtGui import QAction, QDesktopServices
from PySide6.QtWidgets import QDialog, QLabel, QPushButton, QProgressBar, QVBoxLayout, QHBoxLayout, QApplication
from .desktop import Transport
from .updates import (build_info, native_target, validate_release, is_newer,
                      download_release, install_release, Cancelled)


class Events(QObject):
    progress = Signal(object, object)
    complete = Signal(str, str)
    failed = Signal(str)


class UpdateController(QObject):
    def __init__(self, window, guard):
        super().__init__(window)
        self.window = window
        self.guard = guard
        self.product = guard.session.product
        self.info = build_info(self.product)
        self.target = native_target()
        self.transport = Transport(self)
        self.dialog = None
        self.release = None
        self.archive = None
        self.installed = None
        self.busy = False
        self.checking = False
        self.cancel = threading.Event()
        self.events = Events(self)
        self.events.progress.connect(self.progress)
        self.events.complete.connect(self.completed)
        self.events.failed.connect(self.failed)
        self.action = QAction('检查更新…', window)
        self.action.triggered.connect(lambda: self.check(False))
        window.menuBar().addMenu('帮助').addAction(self.action)
        QApplication.instance().aboutToQuit.connect(self.cancel_work)
        self.startup_timer = QTimer(self)
        self.startup_timer.setSingleShot(True)
        self.startup_timer.timeout.connect(lambda: self.check(True))
        self.startup_timer.start(3000)

    def cancel_work(self):
        self.cancel.set()

    def show_dialog(self):
        if self.dialog is None:
            self.dialog = QDialog(self.window)
            self.dialog.setWindowTitle('软件更新')
            self.dialog.setMinimumWidth(470)
            self.dialog.setAttribute(Qt.WA_DeleteOnClose, False)
            layout = QVBoxLayout(self.dialog)
            self.title = QLabel(f"当前版本：{self.info['version']}  ·  {self.target or '不支持的平台'}")
            layout.addWidget(self.title)
            self.message = QLabel()
            self.message.setWordWrap(True)
            self.message.setTextFormat(Qt.PlainText)
            layout.addWidget(self.message)
            self.bar = QProgressBar()
            self.bar.setRange(0, 100)
            layout.addWidget(self.bar)
            row = QHBoxLayout()
            self.primary = QPushButton('下载更新')
            self.primary.clicked.connect(self.perform)
            self.secondary = QPushButton('取消任务')
            self.secondary.clicked.connect(self.cancel_work)
            self.folder = QPushButton('打开所在目录')
            self.folder.clicked.connect(self.open_folder)
            row.addWidget(self.primary)
            row.addWidget(self.secondary)
            row.addWidget(self.folder)
            layout.addLayout(row)
            self.primary.setEnabled(False)
            self.secondary.setEnabled(False)
            self.folder.setEnabled(False)
        self.dialog.show()
        self.dialog.raise_()

    def check(self, silent=False):
        if self.busy or self.checking:
            if not silent:
                self.show_dialog()
            return
        if self.guard.locked:
            return
        if not self.target:
            if not silent:
                self.show_dialog()
                self.message.setText('当前平台暂无更新包。')
            return
        self.checking = True
        self.release = self.archive = self.installed = None
        if not silent:
            self.show_dialog()
            self.primary.setEnabled(False)
            self.folder.setEnabled(False)
            self.message.setText('正在检查新版本…')
        session = self.guard.session
        path = f'/api/updates/{self.product}/{self.target}?version={quote(self.info["version"])}'
        self.transport.request(session.url, path, lambda ok, status, data: self.checked(ok, status, data, silent), session.token)

    def checked(self, ok, status, data, silent):
        self.checking = False
        if self.guard.locked:
            return
        if not ok:
            if not silent:
                self.show_dialog()
                self.message.setText('无法检查更新，请检查网络或重新登录。')
            return
        if not data.get('available'):
            if not silent:
                self.show_dialog()
                self.message.setText('当前已是最新版本。' if data.get('configured') else '管理员尚未配置此平台的更新包。')
            return
        try:
            release = validate_release(data.get('release'), self.product, self.target)
            if not is_newer(release['version'], self.info['version']):
                raise ValueError('更新版本不高于当前版本')
        except ValueError as exc:
            if not silent:
                self.show_dialog()
                self.message.setText(str(exc))
            return
        self.release = release
        self.show_dialog()
        self.message.setText(f"发现 {release['version']}（{release['size']/1024/1024:.1f} MB）\n"
                             f"{release['notes']}\n\n下载来源：GitCode")
        self.primary.setText('下载更新')
        self.primary.setEnabled(True)
        self.folder.setEnabled(False)
        self.bar.setValue(0)

    def perform(self):
        if self.busy or not self.release or self.guard.locked:
            return
        if self.installed:
            self.launch_installed()
            return
        self.busy = True
        self.cancel = threading.Event()
        self.primary.setEnabled(False)
        self.secondary.setEnabled(True)
        self.bar.setValue(0)
        mode = 'install' if self.archive else 'download'
        self.message.setText('正在安装新版本，原软件和当前工作保持不变…' if self.archive else '正在从 GitCode 下载并校验…')
        release, archive, cancel, events = dict(self.release), self.archive, self.cancel, self.events
        base = Path(QStandardPaths.writableLocation(QStandardPaths.DownloadLocation) or str(Path.home()/'Downloads'))
        downloads = base/'汉字工具更新'/self.product
        installs = ((Path.home()/'Applications'/'HanziTools') if sys.platform == 'darwin' else
                    Path(os.environ.get('LOCALAPPDATA', str(Path.home()/'.local/share')))/'HanziTools') / self.product

        def emit(signal, *args):
            try:
                signal.emit(*args)
            except RuntimeError:
                cancel.set()  # application/window already destroyed

        def work():
            try:
                progress = lambda done, total: emit(events.progress, done, total)
                if mode == 'download':
                    output = download_release(release, downloads, cancel, progress)
                else:
                    output = install_release(archive, release, installs, cancel, progress)
                emit(events.complete, mode, str(output))
            except Cancelled:
                emit(events.failed, '已取消，原软件和当前工作保持不变。')
            except Exception as exc:
                # Network exceptions may include signed URLs; show a bounded user-facing error.
                message = str(exc) if isinstance(exc, ValueError) else '更新失败，请检查网络、磁盘空间或联系管理员。'
                emit(events.failed, message)
        # Files go into temporary directories; abrupt app exit cannot damage an installed app.
        threading.Thread(target=work, name='hanzi-update', daemon=True).start()

    def progress(self, done, total):
        self.bar.setValue(min(100, int(done * 100 / max(total, 1))))

    def completed(self, mode, path):
        self.busy = False
        self.secondary.setEnabled(False)
        self.primary.setEnabled(True)
        self.folder.setEnabled(True)
        self.bar.setValue(100)
        if mode == 'download':
            self.archive = Path(path)
            self.primary.setText('安装新版本')
            self.message.setText('下载及 SHA-256 校验通过。新版本将安装到独立目录，保留旧版本和当前工作。')
        else:
            self.installed = Path(path)
            self.primary.setText('打开新版本')
            self.message.setText('新版本已安装。打开后请保存当前工作并退出旧版本；以后请从新版本目录启动。')

    def failed(self, message):
        self.busy = False
        self.secondary.setEnabled(False)
        self.primary.setEnabled(bool(self.release))
        self.message.setText(message)

    def launch_installed(self):
        try:
            if sys.platform == 'darwin':
                subprocess.Popen(['open', str(self.installed)])
            else:
                subprocess.Popen([str(self.installed)], cwd=self.installed.parent)
        except OSError:
            self.message.setText('启动失败，请打开安装目录后手动启动。')

    def open_folder(self):
        path = self.installed or self.archive
        if path:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path.parent)))
