"""Bounded, direct HTTPS transfers for the server-side release mirror."""
from contextlib import contextmanager
import hashlib
from pathlib import Path
from urllib.parse import urlsplit

import httpx


class MirrorError(Exception):
    """Safe, operator-facing error; never include URLs, tokens or response bodies."""


class RemoteError(MirrorError):
    def __init__(self, service, status):
        self.status = status
        self.service = service
        message = f'{service} 返回 HTTP {status}'
        if service.startswith('GitCode') and status == 401:
            message += '：认证失败，请更新实际生效的 GitCode Token（环境变量优先于 .env，.env 优先于后台保存的令牌）'
        elif service.startswith('GitCode') and status == 403:
            message += '：权限不足，请检查令牌的仓库与 Release 访问权限'
        super().__init__(message)


def secure_url(url):
    parsed = urlsplit(url)
    if parsed.scheme != 'https' or not parsed.hostname or parsed.username or parsed.password or parsed.port not in (443, None):
        raise MirrorError('远端地址必须使用 HTTPS')
    return parsed.hostname


def accelerator_prefix(value):
    if not value:
        return ''
    value = value.strip()
    secure_url(value)
    parsed = urlsplit(value)
    if parsed.query or parsed.fragment or parsed.hostname in {'localhost', '127.0.0.1', '::1'}:
        raise MirrorError('加速地址应为 HTTPS 服务前缀，不包含查询参数或片段')
    return value.rstrip('/') + '/'


class HTTP:
    def __init__(self, stop, progress=lambda done, total: None, client=None):
        self.stop, self.progress = stop, progress
        self._json_cache = {}
        # Ignore environment/system proxies. Credentials are attached per API request only.
        self.client = client or httpx.Client(trust_env=False, follow_redirects=False,
                                             timeout=httpx.Timeout(45, connect=15),
                                             headers={'User-Agent': 'HanziReleaseMirror/1'})

    def close(self):
        self.client.close()

    def check(self):
        if self.stop.is_set():
            raise MirrorError('同步已停止')

    def json(self, method, url, token, service, **kwargs):
        self.check()
        secure_url(url)
        # A single polling round shares the public repository listing between products.
        # This keeps anonymous polling below GitHub's hourly limit at the default interval.
        key = (url, token) if method == 'GET' and url.startswith('https://api.github.com/') and not kwargs else None
        if key is not None and key in self._json_cache:
            return self._json_cache[key]
        try:
            headers = {'Accept': 'application/json'}
            if token:
                headers['Authorization'] = 'Bearer ' + token
            response = self.client.request(method, url, headers=headers, **kwargs)
            if not 200 <= response.status_code < 300:
                raise RemoteError(service, response.status_code)
            data = response.json()
            if key is not None:
                self._json_cache[key] = data
            return data
        except (httpx.HTTPError, ValueError) as exc:
            raise MirrorError(f'{service} 请求失败（{type(exc).__name__}）') from None

    @contextmanager
    def stream(self, url, headers=None, github=False):
        headers = dict(headers or {})
        for _ in range(6):
            self.check()
            host = secure_url(url)
            if github and host not in {'api.github.com', 'release-assets.githubusercontent.com',
                                       'objects.githubusercontent.com', 'github.com'}:
                raise MirrorError('GitHub 下载重定向到了未允许的域名')
            # An API token must never travel to the binary CDN, including same-host redirects.
            if host != 'api.github.com':
                headers.pop('Authorization', None)
            with self.client.stream('GET', url, headers=headers) as response:
                if response.is_redirect:
                    next_url = str(response.url.join(response.headers['location']))
                    secure_url(next_url)
                    headers.pop('Authorization', None)
                    url = next_url
                    continue
                yield response
                return
        raise MirrorError('下载重定向次数过多')

    def download(self, url, path, size, sha256, token='', *, accelerator='', public_url='', route=lambda value: None):
        """Use a public-asset relay without credentials; fall back to the authenticated API."""
        prefix = accelerator_prefix(accelerator)
        if prefix and public_url:
            parsed = urlsplit(public_url)
            if (secure_url(public_url) != 'github.com' or parsed.query or parsed.fragment
                    or '/releases/download/' not in parsed.path):
                raise MirrorError('外部加速只接受 GitHub 公开发行版附件链接')
            route('外部加速：' + urlsplit(prefix).hostname)
            try:
                return self._download(prefix + public_url, path, size, sha256, github=False)
            except MirrorError:
                self.check()
                route('外部加速失败，已回退 GitHub 直连')
        else:
            route('GitHub API 直连')
        return self._download(url, path, size, sha256, token)

    def _download(self, url, path, size, sha256, token='', github=True):
        """Resume partial files; restart if the server ignores Range; verify before rename."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists() and file_digest(path) == (size, sha256):
            self.progress(size, size)
            return path
        partial = path.with_suffix(path.suffix + '.part')
        offset = partial.stat().st_size if partial.exists() else 0
        if offset >= size:
            if offset == size and file_digest(partial) == (size, sha256):
                partial.replace(path)
                self.progress(size, size)
                return path
            partial.unlink()
            offset = 0
        headers = {'Accept': 'application/octet-stream', 'Accept-Encoding': 'identity'}
        if token:
            headers['Authorization'] = 'Bearer ' + token
        if offset:
            headers['Range'] = f'bytes={offset}-'
        try:
            with self.stream(url, headers, github=github) as response:
                if response.status_code not in (200, 206):
                    raise RemoteError('GitHub 下载', response.status_code)
                if response.status_code == 206:
                    content_range = response.headers.get('content-range', '')
                    if not content_range.startswith(f'bytes {offset}-') or not content_range.endswith(f'/{size}'):
                        raise MirrorError('下载续传位置不匹配')
                else:
                    offset = 0
                count = offset
                with partial.open('ab' if offset else 'wb') as output:
                    for chunk in response.iter_bytes(1024 * 1024):
                        self.check()
                        count += len(chunk)
                        if count > size:
                            raise MirrorError('下载大小超过 GitHub 附件记录')
                        output.write(chunk)
                        self.progress(count, size)
            if file_digest(partial) != (size, sha256):
                partial.unlink(missing_ok=True)
                raise MirrorError('GitHub 安装包大小或 SHA-256 不匹配')
            partial.replace(path)
            return path
        except httpx.HTTPError as exc:
            raise MirrorError(f'GitHub 下载中断，下一次继续（{type(exc).__name__}）') from None

    def verify_public(self, url, size, sha256):
        """Verify the whole public object, without either service's credentials."""
        try:
            with self.stream(url, {'Accept-Encoding': 'identity'}) as response:
                if response.status_code == 404:
                    return False
                if response.status_code != 200:
                    raise RemoteError('GitCode 公开下载', response.status_code)
                digest, count = hashlib.sha256(), 0
                for chunk in response.iter_bytes(1024 * 1024):
                    self.check()
                    count += len(chunk)
                    if count > size:
                        raise MirrorError('GitCode 同名附件内容不同，请人工核对')
                    digest.update(chunk)
                    self.progress(count, size)
                if (count, digest.hexdigest()) != (size, sha256):
                    raise MirrorError('GitCode 同名附件校验不符，请人工核对')
                return True
        except httpx.HTTPError as exc:
            raise MirrorError(f'GitCode 公开下载验证失败（{type(exc).__name__}）') from None

    def upload(self, info, path):
        secure_url(info['url'])
        # Only use the exact object-storage headers supplied by GitCode, never API credentials.
        headers = dict(info['headers'])
        headers['Content-Length'] = str(path.stat().st_size)
        def chunks():
            count = 0
            with path.open('rb') as source:
                while chunk := source.read(1024 * 1024):
                    self.check()
                    count += len(chunk)
                    self.progress(count, path.stat().st_size)
                    yield chunk
        try:
            response = self.client.put(info['url'], headers=headers, content=chunks())
            if not 200 <= response.status_code < 300:
                raise RemoteError('GitCode 上传', response.status_code)
        except httpx.HTTPError as exc:
            raise MirrorError(f'GitCode 上传中断（{type(exc).__name__}）') from None


def file_digest(path):
    digest, size = hashlib.sha256(), 0
    with Path(path).open('rb') as source:
        while chunk := source.read(1024 * 1024):
            size += len(chunk)
            digest.update(chunk)
    return size, digest.hexdigest()
