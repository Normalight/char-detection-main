"""Administrative release registration and authenticated update discovery."""
import json
import time
from fastapi import Depends, HTTPException, Query
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, Field
from .updates import PRODUCTS, TARGETS, is_newer, validate_release, validate_download_url


class ReleaseInput(BaseModel):
    version: str = Field(min_length=1, max_length=64)
    url: str = Field(min_length=1, max_length=2048)
    sha256: str = Field(min_length=64, max_length=64)
    size: int = Field(gt=0, le=4 * 1024**3)
    notes: str = Field(default='', max_length=2000)
    enabled: bool = True


def add_routes(app, store, current, administrator):
    def download_products(session):
        row = session[0]
        if row['product'] not in {'portal', 'admin'}:
            raise HTTPException(403, '请登录下载平台')
        return PRODUCTS if row['admin'] else set(json.loads(row['products']))

    @app.get('/api/downloads')
    def downloads(session=Depends(current)):
        permitted = download_products(session)
        with store.connect() as db:
            rows = db.execute('SELECT * FROM releases WHERE enabled=1 ORDER BY product,target').fetchall()
        items = []
        for product in sorted(permitted):
            packages = []
            for row in rows:
                if row['product'] != product or row['target'] not in TARGETS:
                    continue
                release = json.loads(row['metadata'])
                packages.append({key: release.get(key, '') for key in ('target', 'version', 'size', 'notes', 'sha256')} |
                                {'download_path': '/api/downloads/' + product + '/' + row['target'],
                                 'published_at': row['published_at']})
            items.append({'product': product, 'packages': packages})
        return items

    @app.get('/api/downloads/{product}/{target}')
    def download(product: str, target: str, session=Depends(current)):
        permitted = download_products(session)
        if product not in permitted:
            raise HTTPException(403, '此账号未获授权下载该软件')
        if target not in TARGETS:
            raise HTTPException(404, '安装包不存在')
        with store.connect() as db:
            row = db.execute('SELECT metadata FROM releases WHERE product=? AND target=? AND enabled=1',
                             (product, target)).fetchone()
        if row is None:
            raise HTTPException(404, '此平台暂无可下载的安装包')
        try:
            url = validate_download_url(json.loads(row['metadata'])['url'])
        except (ValueError, KeyError):
            raise HTTPException(503, '安装包地址暂不可用')
        return RedirectResponse(url, status_code=302, headers={'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer'})

    @app.get('/api/admin/updates')
    def list_updates(admin=Depends(administrator)):
        with store.connect() as db:
            return [json.loads(row['metadata']) | {'enabled': bool(row['enabled']), 'published_at': row['published_at']}
                    for row in db.execute('SELECT * FROM releases ORDER BY product, target')]

    @app.put('/api/admin/updates/{product}/{target}')
    def register(product: str, target: str, body: ReleaseInput, admin=Depends(administrator)):
        try:
            release = validate_release(body.model_dump() | {'product': product, 'target': target})
        except ValueError as exc:
            raise HTTPException(422, str(exc))
        with store.connect() as db:
            db.execute('''INSERT INTO releases VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(product, target) DO UPDATE SET metadata=excluded.metadata,
                enabled=excluded.enabled, published_at=excluded.published_at''',
                (product, target, json.dumps(release), int(body.enabled), int(time.time())))
            db.execute("INSERT INTO audit VALUES (?, ?, 'publish_update', ?)",
                       (int(time.time()), admin['username'], product + '/' + target + '/' + body.version))
        return {'ok': True}

    @app.get('/api/updates/{product}/{target}')
    def check(product: str, target: str, version: str = Query(default='v0.0.0-dev', max_length=64),
              session=Depends(current)):
        if product not in PRODUCTS or target not in TARGETS:
            raise HTTPException(400, '未知软件或平台')
        if session[0]['product'] != product:
            raise HTTPException(403, '请使用对应软件的登录会话检查更新')
        with store.connect() as db:
            row = db.execute('SELECT * FROM releases WHERE product=? AND target=? AND enabled=1',
                             (product, target)).fetchone()
        if row is None:
            return {'available': False, 'configured': False}
        release = json.loads(row['metadata'])
        if not is_newer(release['version'], version):
            return {'available': False, 'configured': True, 'latest_version': release['version']}
        return {'available': True, 'configured': True, 'release': release}
