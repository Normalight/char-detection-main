"""Local polling mirror: GitHub release -> checked ZIPs -> GitCode -> update catalogue."""
import argparse
import hashlib
from contextlib import contextmanager
import json
import logging
import sqlite3
import os
from pathlib import Path
import re
import stat
import subprocess
import tempfile
import threading
import time
from urllib.parse import quote
import zipfile

from dotenv import dotenv_values

from .mirror_http import HTTP, MirrorError, RemoteError, accelerator_prefix
from .updates import MAX_DOWNLOAD, TARGETS, parsed_version, validate_download_url, validate_release

REPOSITORIES = [
    {'product': name, 'github': 'Normalight/hanzi-soft', 'gitcode': 'qq_28599947/hanzi-soft',
     'tag_prefix': name + '-', 'destination_tag_prefix': name + '-', 'distribution': True}
    for name in ('char-detection-main', 'group-by-character')
]
DEFAULT_CONFIG = {'enabled': False, 'interval_seconds': 300, 'repositories': REPOSITORIES,
                  'download_accelerator': 'https://ghfast.top/'}


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(dir=path.parent, prefix='.' + path.name)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


@contextmanager
def exclusive(path):
    """OS lock is released on crashes; coordinate the server and one-shot CLI."""
    with Path(path).open('a+b') as stream:
        stream.seek(0)
        stream.write(b'0')
        stream.flush()
        stream.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            raise MirrorError('另一同步进程正在运行') from None
        try:
            yield
        finally:
            if os.name == 'nt':
                stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def select_release(releases, tag_prefix=''):
    candidates = []
    for release in releases:
        if release.get('draft') or release.get('prerelease'):
            continue
        tag = release.get('tag_name', '')
        if not isinstance(tag, str) or not tag.startswith(tag_prefix):
            continue
        try:
            version = parsed_version(tag[len(tag_prefix):])
        except ValueError:
            continue
        if not version.is_prerelease:
            candidates.append((version, release))
    return max(candidates, key=lambda item: item[0])[1] if candidates else None


def select_assets(release):
    selected = {}
    tag = release['tag_name']
    for asset in release.get('assets', []):
        name = asset.get('name', '')
        if not name.endswith('.zip'):
            continue
        if '/' in name or '\\' in name or ':' in name or any(ord(c) < 32 for c in name):
            raise MirrorError('GitHub 附件文件名不安全')
        target = next((t for t in TARGETS if name.endswith(f'-{tag}-{t}.zip')), None)
        if not target:
            continue
        if target in selected:
            raise MirrorError('同一平台存在多个安装包，请核对 GitHub Release')
        digest = asset.get('digest') or ''
        if not re.fullmatch(r'sha256:[0-9a-fA-F]{64}', digest):
            raise MirrorError('GitHub 附件缺少 SHA-256，请重新上传构建产物')
        if type(asset.get('size')) is not int or not 0 < asset['size'] <= MAX_DOWNLOAD:
            raise MirrorError('GitHub 附件大小无效')
        if asset.get('state') != 'uploaded':
            continue
        selected[target] = asset
    if not selected:
        raise MirrorError('等待 GitHub 构建完成：暂无可同步的平台 ZIP')
    return selected


def inspect_package(path, product, target, version):
    try:
        with zipfile.ZipFile(path) as archive:
            infos = [i for i in archive.infolist() if i.filename.split('/')[-1] == 'build_info.json'
                     and not stat.S_ISLNK(i.external_attr >> 16)]
            if not infos or len(infos) > 16:
                raise MirrorError('安装包缺少唯一软件的构建信息，请重新打包')
            for info in infos:
                if info.file_size > 4096:
                    raise MirrorError('安装包构建信息异常')
                data = json.loads(archive.read(info))
                if (data.get('product') != product or data.get('target') != target or
                        parsed_version(data.get('version')) != parsed_version(version)):
                    raise MirrorError('安装包内部的软件、平台或版本与发布信息不符')
    except (ValueError, zipfile.BadZipFile, KeyError):
        raise MirrorError('安装包构建信息不可读') from None


class Mirror:
    def __init__(self, store):
        self.store = store
        self.env_path = Path.cwd() / ".env"
        self.directory = store.path.parent / 'release-mirror'
        self.directory.mkdir(parents=True, exist_ok=True)
        self.config_path = self.directory / 'config.json'
        self.stop = threading.Event()
        self.wake = threading.Event()
        self.guard = threading.Lock()
        self.config_guard = threading.Lock()
        self.thread = None
        self.running = False
        self.manual = False
        self.state = {'stage': 'idle', 'message': '等待检查', 'checked_at': None,
                      'done': 0, 'total': 0, 'results': [], 'files_done': 0, 'files_total': 0,
                      'products_done': 0, 'products_total': 0, 'product': '', 'filename': ''}
        with store.connect() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS mirror_assets (
                source TEXT NOT NULL, tag TEXT NOT NULL, name TEXT NOT NULL,
                fingerprint TEXT NOT NULL, metadata TEXT NOT NULL,
                PRIMARY KEY(source, tag, name))''')

    def config(self):
        try:
            data = (json.loads(self.config_path.read_text(encoding='utf-8'))
                    if self.config_path.exists() else dict(DEFAULT_CONFIG))
            data['download_accelerator'] = accelerator_prefix(data.get('download_accelerator', 'https://ghfast.top/'))
            if type(data['enabled']) is not bool or not 60 <= data['interval_seconds'] <= 86400:
                raise ValueError()
            seen = set()
            for repo in data['repositories']:
                if repo['product'] not in {r['product'] for r in REPOSITORIES} or repo['product'] in seen:
                    raise ValueError()
                seen.add(repo['product'])
                if repo.get('destination_tag_prefix', '') not in ('', repo['product'] + '-'):
                    raise ValueError()
                if repo.get('tag_prefix', '') not in ('', repo['product'] + '-') or type(repo.get('distribution', False)) is not bool:
                    raise ValueError()
                for field in ('github', 'gitcode'):
                    if not re.fullmatch(r'[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+', repo[field]):
                        raise ValueError()
            return data
        except (ValueError, KeyError, TypeError, OSError):
            raise MirrorError('同步配置无效，请检查 release-mirror/config.json') from None

    def credentials(self, service):
        env = os.getenv(service.upper() + '_TOKEN', '').strip()
        if env:
            return env
        value = dotenv_values(self.env_path, interpolate=False).get(service.upper() + '_TOKEN', '')
        if value and value.strip():
            return value.strip()
        path = self.directory / 'credentials.json'
        if path.exists():
            token = json.loads(path.read_text(encoding='utf-8')).get(service, '').strip()
            if token:
                return token
        if service == 'github':
            try:
                result = subprocess.run(['gh', 'auth', 'token'], capture_output=True, text=True, timeout=10)
                if result.returncode == 0:
                    return result.stdout.strip()
            except (OSError, subprocess.TimeoutExpired):
                pass
        return ''

    def credential_source(self, service):
        if os.getenv(service.upper() + '_TOKEN', '').strip():
            return '进程环境变量'
        if (dotenv_values(self.env_path, interpolate=False).get(service.upper() + '_TOKEN') or '').strip():
            return '.env 文件'
        path = self.directory / 'credentials.json'
        if path.exists() and json.loads(path.read_text(encoding='utf-8')).get(service, '').strip():
            return '后台保存的令牌'
        return '未配置'

    def configure(self, enabled, github_token='', gitcode_token='', download_accelerator=None):
        with self.config_guard:
            config = self.config()
            config['enabled'] = enabled
            if download_accelerator is not None:
                config['download_accelerator'] = accelerator_prefix(download_accelerator)
            path = self.directory / 'credentials.json'
            tokens = json.loads(path.read_text(encoding='utf-8')) if path.exists() else {}
            for key, value in [('github', github_token), ('gitcode', gitcode_token)]:
                if value.strip():
                    tokens[key] = value.strip()
            if github_token or gitcode_token:
                atomic_json(path, tokens)
            atomic_json(self.config_path, config)
        self.wake.set()

    def set_state(self, **values):
        with self.guard:
            self.state.update(values)

    def snapshot(self):
        config = self.config()
        current_versions = []
        with self.store.connect() as db:
            rows = db.execute('SELECT product, target, metadata, enabled, published_at FROM releases ORDER BY target').fetchall()
        for repo in REPOSITORIES:
            targets = [{'target': row['target'], 'version': json.loads(row['metadata'])['version'],
                        'notes': json.loads(row['metadata']).get('notes', ''),
                        'enabled': bool(row['enabled']), 'published_at': row['published_at']}
                       for row in rows if row['product'] == repo['product'] and row['target'] in TARGETS]
            versions = {item['version'] for item in targets}
            release_notes = []
            for item in targets:
                if not any(note['version'] == item['version'] and note['notes'] == item['notes'] for note in release_notes):
                    release_notes.append({'version': item['version'], 'notes': item['notes']})
            current_versions.append({'product': repo['product'],
                                     'version': next(iter(versions)) if len(versions) == 1 else None,
                                     'mixed': len(versions) > 1, 'targets': targets,
                                     'release_notes': release_notes})
        with self.guard:
            return dict(self.state, running=self.running, enabled=config['enabled'],
                        current_versions=current_versions,
                        interval_seconds=config['interval_seconds'], repositories=config['repositories'],
                        download_accelerator=config['download_accelerator'],
                        gitcode_token_source=self.credential_source('gitcode'))

    def trigger(self):
        with self.guard:
            if self.running or self.manual:
                return False
            self.manual = True
        self.wake.set()
        return True

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self.loop, name='release-mirror', daemon=True)
        self.thread.start()

    def close(self):
        self.stop.set()
        self.wake.set()
        if self.thread:
            self.thread.join(timeout=50)

    def loop(self):
        while not self.stop.is_set():
            self.wake.clear()
            interval = 300
            config = {'enabled': False}
            try:
                config = self.config()
                interval = config['interval_seconds']
                with self.guard:
                    manual, self.manual = self.manual, False
                if config['enabled'] or manual:
                    self.run_once(trigger='manual' if manual else 'automatic')
            except Exception as exc:
                self.set_state(stage='error', message=self.safe_error(exc))
            self.set_state(next_check_at=int(time.time()) + interval if config['enabled'] else None)
            self.wake.wait(interval)

    @staticmethod
    def safe_error(exc):
        return str(exc) if isinstance(exc, MirrorError) else f'同步失败（{type(exc).__name__}），请检查配置或网络'

    def progress(self, done, total):
        self.set_state(done=done, total=total)

    def record_event(self, event, **details):
        try:
            with self.store.connect() as db:
                db.execute("INSERT INTO audit VALUES (?, 'release-mirror', 'mirror_check', ?)",
                           (int(time.time()), json.dumps(dict(event=event, **details), ensure_ascii=False)))
        except sqlite3.Error:
            logging.getLogger(__name__).exception('无法保存同步检查记录')

    def run_once(self, trigger='manual'):
        with self.guard:
            if self.running:
                return
            self.running = True
        self.set_state(stage='checking', message='正在检查 GitCode 认证', done=0, total=0,
                       results=[], files_done=0, files_total=0, products_done=0, products_total=0,
                       product='', filename='', download_route='')
        http = HTTP(self.stop, self.progress)
        results = []
        try:
            self.set_state(trigger=trigger, started_at=int(time.time()), next_check_at=None)
            self.record_event('started', trigger=trigger)
            with exclusive(self.directory / 'worker.lock'):
                config = self.config()
                github, gitcode = self.credentials('github'), self.credentials('gitcode')
                if not gitcode:
                    raise MirrorError('请配置本机 GitCode Token；GitHub 公共仓库可匿名读取')
                self.set_state(products_total=len(config['repositories']))
                http.json('GET', 'https://api.gitcode.com/api/v5/user', gitcode, 'GitCode 账号认证')
                for repo in config['repositories']:
                    http.check()
                    try:
                        self.record_event('product_started', product=repo['product'], trigger=trigger)
                        self.sync_repo(http, repo, github, gitcode)
                        results.append({'product': repo['product'], 'ok': True, 'message': '同步完成'})
                    except Exception as exc:
                        results.append({'product': repo['product'], 'ok': False, 'message': self.safe_error(exc)})
                    self.record_event('product_finished', trigger=trigger, **results[-1])
                    self.set_state(results=list(results), products_done=len(results))
                self.set_state(stage='done' if all(r['ok'] for r in results) else 'error',
                               message='全部同步完成，客户端更新已就绪' if all(r['ok'] for r in results) else
                               '本轮存在失败项，请查看下方原因并重试', results=results)
        except Exception as exc:
            self.set_state(stage='error', message=self.safe_error(exc))
        finally:
            self.record_event('finished', trigger=trigger, stage=self.state['stage'], message=self.state['message'])
            http.close()
            self.set_state(checked_at=int(time.time()))
            with self.guard:
                self.running = False

    def sync_repo(self, http, repo, github_token, gitcode_token):
        source = 'https://api.github.com/repos/' + repo['github']
        destination = 'https://api.gitcode.com/api/v5/repos/' + repo['gitcode']
        self.set_state(stage='checking', message=repo['product'] + '：检查 GitCode Release 权限',
                       product=repo['product'], filename='', files_done=0, files_total=0, done=0, total=0, download_route='')
        http.json('GET', destination + '/releases?per_page=1', gitcode_token, 'GitCode Release')
        accelerator = self.config()['download_accelerator']
        if accelerator:
            repository = http.json('GET', source, github_token, 'GitHub 仓库')
            if repository.get('private') is not False:
                accelerator = ''
                self.set_state(download_route='私有仓库：使用 GitHub API 直连')
        self.set_state(stage='checking', message=repo['product'] + '：检查 GitHub 新版本', done=0, total=0)
        releases = http.json('GET', source + '/releases?per_page=100', github_token, 'GitHub')
        prefix = repo.get('tag_prefix', '')
        release = select_release(releases, prefix)
        if release is None:
            raise MirrorError('尚无正式版本')
        release = dict(release)
        github_tag = release['tag_name']
        tag = github_tag[len(prefix):]
        self.record_event('version_found', product=repo['product'], version=tag)
        release['tag_name'] = tag
        # Fetch the full paginated asset set; release events precede build completion.
        assets = []
        for page in range(1, 11):
            batch = http.json('GET', source + f"/releases/{int(release['id'])}/assets?per_page=100&page={page}", github_token, 'GitHub')
            assets.extend(batch)
            if len(batch) < 100:
                break
        release['assets'] = assets
        selected = select_assets(release)
        destination_release = dict(release, tag_name=repo.get('destination_tag_prefix', '') + tag)
        records = []
        self.set_state(files_total=len(selected))
        failures = []
        for index, (target, asset) in enumerate(sorted(selected.items()), 1):
            try:
                signature = json.dumps([repo['gitcode'], destination_release['tag_name'], asset['id'], asset.get('updated_at'), asset['digest'], asset['size']])
                with self.store.connect() as db:
                    cached = db.execute('SELECT * FROM mirror_assets WHERE source=? AND tag=? AND name=?',
                                        (repo['github'], tag, asset['name'])).fetchone()
                if cached:
                    if cached['fingerprint'] != signature:
                        raise MirrorError('已同步版本的同名附件发生变化，请发布新版本号')
                    record = json.loads(cached['metadata'])
                    self.publish_platform(http, destination, destination_release, asset, record, gitcode_token)
                    records.append(record)
                    continue
                sha = asset['digest'].split(':', 1)[1].lower()
                local = self.directory / 'downloads' / repo['product'] / tag / (str(asset['id']) + '-' + asset['name'])
                self.set_state(stage='downloading', message=repo['product'] + '：下载 ' + asset['name'], done=0, total=asset['size'], filename=asset['name'])
                public_url = ('https://github.com/' + repo['github'] + '/releases/download/'
                              + quote(github_tag, safe='') + '/' + quote(asset['name'], safe='')) if accelerator else ''
                http.download(source + f"/releases/assets/{int(asset['id'])}", local, asset['size'], sha, github_token,
                              accelerator=accelerator, public_url=public_url,
                              route=lambda value: self.set_state(download_route=value if accelerator else
                                  'GitHub API 直连（未启用加速或仓库为私有）'))
                self.set_state(stage='verifying', message='校验本机安装包：' + asset['name'], done=0, total=0)
                inspect_package(local, repo['product'], target, tag)
                self.ensure_release(http, source, destination, destination_release, github_token, gitcode_token,
                                    distribution=repo.get('distribution', False))
                remote_url = self.mirror_asset(http, destination, destination_release, asset, local, sha, gitcode_token)
                record = validate_release({'product': repo['product'], 'target': target, 'version': tag,
                                           'url': remote_url, 'size': asset['size'], 'sha256': sha,
                                           'notes': (release.get('body') or '')[:2000]})
                with self.store.connect() as db:
                    db.execute('INSERT INTO mirror_assets VALUES (?, ?, ?, ?, ?)',
                               (repo['github'], tag, asset['name'], signature, json.dumps(record)))
                self.publish_platform(http, destination, destination_release, asset, record, gitcode_token)
                records.append(record)
            except Exception as exc:
                http.check()
                failures.append(target + '：' + self.safe_error(exc))
            finally:
                self.set_state(files_done=index)
        # The legacy manifest is immutable: create it only when all platforms are ready.
        # Platform manifests can be published independently as each build becomes available.
        if {record['target'] for record in records} == TARGETS:
            self.publish_manifest(http, destination, destination_release, records, selected,
                                  'hanzi-update.json', gitcode_token)
        self.set_state(files_done=len(selected), files_total=len(selected))
        if failures:
            raise MirrorError('部分平台同步失败；已完成的平台可更新。' + '；'.join(failures))

    def publish_manifest(self, http, destination, release, records, selected, name, token):
        product = records[0]['product']
        manifest = self.directory / 'downloads' / product / records[0]['version'] / name
        atomic_json(manifest, [record | {'name': selected[record['target']]['name']} for record in records])
        payload = manifest.read_bytes()
        self.mirror_asset(http, destination, release, {'name': name, 'size': len(payload)},
                          manifest, hashlib.sha256(payload).hexdigest(), token)

    def publish_platform(self, http, destination, release, asset, record, token):
        self.publish_manifest(http, destination, release, [record], {record['target']: asset},
                              'hanzi-update-' + record['target'] + '.json', token)
        self.publish([record])

    def ensure_release(self, http, source, destination, release, github_token, gitcode_token, distribution=False):
        tag = quote(release['tag_name'], safe='')
        if distribution:
            try:
                http.json('GET', destination + '/releases/tags/' + tag, gitcode_token, 'GitCode Release')
                return
            except RemoteError as exc:
                if exc.status != 404:
                    raise
            # Distribution tags identify packages. Never push private source commits to
            # either public repository; create a missing tag on GitCode's own branch.
            repository = http.json('GET', destination, gitcode_token, 'GitCode 仓库')
            branch = repository.get('default_branch')
            if not branch:
                raise MirrorError('请先在 GitCode 发布仓库初始化 README 和默认分支')
            try:
                http.json('POST', destination + '/releases', gitcode_token, 'GitCode Release', json={
                    'tag_name': release['tag_name'], 'name': release.get('name') or release['tag_name'],
                    'body': release.get('body') or '', 'target_commitish': branch, 'release_status': 'latest'})
            except MirrorError:
                http.json('GET', destination + '/releases/tags/' + tag, gitcode_token, 'GitCode Release')
            return
        # Resolve annotated tags to a commit; only use the exact source commit.
        ref = http.json('GET', source + '/git/ref/tags/' + tag, github_token, 'GitHub 标签')['object']
        for _ in range(5):
            if ref['type'] == 'commit':
                break
            if ref['type'] != 'tag':
                raise MirrorError('GitHub 标签未指向提交')
            ref = http.json('GET', source + '/git/tags/' + ref['sha'], github_token, 'GitHub 标签')['object']
        if ref['type'] != 'commit':
            raise MirrorError('GitHub 标签解析失败')
        # GitCode must already contain the matching tag, preventing accidental wrong-code tags.
        found = None
        for page in range(1, 101):
            batch = http.json('GET', destination + f'/tags?per_page=100&page={page}', gitcode_token, 'GitCode 标签')
            found = next((t for t in batch if t.get('name') == release['tag_name']), None)
            if found or len(batch) < 100:
                break
        if not found:
            raise MirrorError('GitCode 缺少 ' + release['tag_name'] + ' 标签，请先同步代码与标签')
        commit = found.get('commit', {}).get('sha') or found.get('commit', {}).get('id')
        if commit != ref['sha']:
            raise MirrorError('GitCode 标签提交与 GitHub 不一致，请先同步标签')
        try:
            http.json('GET', destination + '/releases/tags/' + tag, gitcode_token, 'GitCode Release')
            return
        except RemoteError as exc:
            if exc.status != 404:
                raise
        try:
            http.json('POST', destination + '/releases', gitcode_token, 'GitCode Release', json={
                'tag_name': release['tag_name'], 'name': release.get('name') or release['tag_name'],
                'body': release.get('body') or '', 'target_commitish': ref['sha'], 'release_status': 'latest'})
        except MirrorError:
            # POST can succeed while its response is lost; query before any later attempt.
            http.json('GET', destination + '/releases/tags/' + tag, gitcode_token, 'GitCode Release')

    def mirror_asset(self, http, destination, release, asset, local, sha, token):
        tag = quote(release['tag_name'], safe='')
        for attempt in range(4):
            self.set_state(stage='verifying', message='检查 GitCode 附件：' + asset['name'], done=0, total=0, filename=asset['name'])
            current = http.json('GET', destination + '/releases/tags/' + tag, token, 'GitCode Release')
            matches = [a for a in current.get('assets', []) if a.get('name') == asset['name']]
            if len(matches) > 1:
                raise MirrorError('GitCode 存在多个同名附件，请人工清理')
            if matches:
                url = validate_download_url(matches[0]['browser_download_url'])
                self.set_state(stage='verifying', message='校验 GitCode 公开下载：' + asset['name'], done=0, total=asset['size'])
                if http.verify_public(url, asset['size'], sha):
                    return url
                raise MirrorError('GitCode 已登记同名附件但无法下载，请删除失败附件后重试')
            if attempt == 3:
                break
            self.set_state(stage='uploading', message='上传 GitCode：' + asset['name'], done=0, total=asset['size'], filename=asset['name'])
            info = http.json('GET', destination + '/releases/' + tag + '/upload_url', token,
                             'GitCode 上传地址', params={'file_name': asset['name']})
            try:
                http.upload(info, local)
            except MirrorError:
                # A lost PUT response may still mean success. Re-read before retrying.
                pass
            # Refresh release metadata and signed upload URL on the next attempt.
            if self.stop.wait(2):
                raise MirrorError('同步已停止')
        raise MirrorError('上传后附件尚未可用，下次检查会重新验证')

    def publish(self, records):
        """Advertise verified platforms; never downgrade or undo manual disables."""
        with self.store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            for record in records:
                old = db.execute('SELECT metadata FROM releases WHERE product=? AND target=?',
                                 (record['product'], record['target'])).fetchone()
                if old:
                    previous = json.loads(old[0])
                    if (previous['version'] == record['version']
                            and previous['sha256'] == record['sha256']
                            and previous['size'] == record['size']
                            and previous['url'] != record['url']):
                        # A verified repository migration may change the URL of the
                        # same bytes. Preserve the administrator's enabled state.
                        previous['url'] = record['url']
                        db.execute('UPDATE releases SET metadata=? WHERE product=? AND target=?',
                                   (json.dumps(previous), record['product'], record['target']))
                    if parsed_version(previous['version']) >= parsed_version(record['version']):
                        continue
                db.execute('''INSERT INTO releases VALUES (?, ?, ?, 1, ?)
                    ON CONFLICT(product, target) DO UPDATE SET metadata=excluded.metadata,
                    enabled=1, published_at=excluded.published_at''',
                           (record['product'], record['target'], json.dumps(record), int(time.time())))
                db.execute("INSERT INTO audit VALUES (?, 'release-mirror', 'publish_update', ?)",
                           (int(time.time()), record['product'] + '/' + record['target'] + '/' + record['version']))


def main():
    parser = argparse.ArgumentParser(description='在本机同步 GitHub 安装包至 GitCode')
    parser.add_argument('--db', default='data/accounts.sqlite3')
    parser.add_argument('--once', action='store_true', help='只检查一轮（忽略自动监听开关）')
    args = parser.parse_args()
    from .server import Store
    mirror = Mirror(Store(args.db))
    if args.once:
        mirror.run_once()
        state = mirror.snapshot()
        print(json.dumps(state, ensure_ascii=False, indent=2))
        raise SystemExit(1 if state['stage'] == 'error' else 0)
    try:
        mirror.loop()
    except KeyboardInterrupt:
        mirror.close()


if __name__ == '__main__':
    main()
