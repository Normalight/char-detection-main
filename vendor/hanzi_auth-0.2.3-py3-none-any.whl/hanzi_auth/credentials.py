"""Remember verified passwords in the native per-user credential vault."""
import hashlib
import sys

from .policy import server_url


def backend():
    # Explicit native backends: never select a plaintext third-party fallback.
    if sys.platform == 'darwin':
        from keyring.backends.macOS import Keyring
        return Keyring()
    if sys.platform == 'win32':
        from keyring.backends.Windows import WinVaultKeyring
        vault = WinVaultKeyring()
        vault.persist = 'local machine'
        return vault
    raise RuntimeError('当前平台不支持安全保存密码')


class CredentialStore:
    def __init__(self, url):
        identity = hashlib.sha256(server_url(url).encode()).hexdigest()
        self.service = 'HanziTools.Authentication.' + identity

    def get(self, username):
        return backend().get_password(self.service, username) or ''

    def set(self, username, password):
        backend().set_password(self.service, username, password)

    def delete(self, username):
        vault = backend()
        if vault.get_password(self.service, username) is not None:
            vault.delete_password(self.service, username)
