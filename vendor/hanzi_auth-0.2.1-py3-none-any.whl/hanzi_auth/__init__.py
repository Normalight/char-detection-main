"""Shared authentication; Qt and server dependencies load only when needed."""
__version__ = "0.2.1"


def require_login(product):
    from .desktop import LoginDialog
    dialog = LoginDialog(product)
    return dialog.session if dialog.exec() else None


def protect_window(window, session, save_callback, lock_callback=None):
    from .desktop import SessionGuard
    guard = SessionGuard(window, session, save_callback, lock_callback)
    window._auth_guard = guard
    from .update_ui import UpdateController
    window._update_controller = UpdateController(window, guard)
    return guard
