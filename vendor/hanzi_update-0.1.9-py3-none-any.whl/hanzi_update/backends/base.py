"""Validated, public-only native updater configuration."""
from dataclasses import dataclass
import base64
import re
from urllib.parse import urlsplit

from ..core import PRODUCTS


def release_version(value):
    version = value.removeprefix('v')
    if not re.fullmatch(r'(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)', version):
        raise ValueError('原生更新需要 major.minor.patch 正式版本')
    parts = tuple(map(int, version.split('.')))
    if any(part > 999 for part in parts):
        raise ValueError('版本分段不能超过 999')
    return version, str(parts[0] * 1000000 + parts[1] * 1000 + parts[2])


@dataclass(frozen=True)
class UpdateConfig:
    product: str
    version: str
    feed_url: str
    public_key: str
    channel: str = 'stable'

    def __post_init__(self):
        if self.product not in PRODUCTS:
            raise ValueError('未知软件')
        release_version(self.version)
        url = urlsplit(self.feed_url)
        if (url.scheme != 'https' or not url.hostname or url.username or url.password
                or url.query or url.fragment or any(c.isspace() for c in self.feed_url)):
            raise ValueError('更新源必须为不含凭据的 HTTPS URL')
        if len(base64.b64decode(self.public_key, validate=True)) != 32:
            raise ValueError('Ed25519 公钥必须为 32 字节')
        if self.channel not in {'stable', 'beta'}:
            raise ValueError('未知更新通道')

    @property
    def build_version(self):
        return release_version(self.version)[1]
