"""Release validation, checked downloads and staged desktop updates."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import shutil
import stat
import sys
import tempfile
from threading import Event
from urllib.error import HTTPError
from urllib.parse import quote, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener
import zipfile

from packaging.version import Version, InvalidVersion

PRODUCTS = {'group-by-character', 'char-detection-main'}
TARGETS = {'windows-x64', 'macos-arm64'}
APP_NAMES = {'group-by-character': '字形归并工具.app', 'char-detection-main': '中文字符标注工具.app'}
EXE_NAMES = {'group-by-character': 'group_by_character.exe', 'char-detection-main': 'interactive_annotator.exe'}
MAX_DOWNLOAD = 4 * 1024**3
MAX_UNPACKED = 12 * 1024**3


def parsed_version(value):
    if not isinstance(value, str) or not re.fullmatch(r'v?\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?', value):
        raise ValueError('版本号需形如 v1.2.3 或 v1.2.3-rc.1')
    try:
        return Version(value.lstrip('v'))
    except InvalidVersion as exc:
        raise ValueError('版本号无效') from exc


def is_newer(candidate, current):
    new = parsed_version(candidate)
    try:
        old = parsed_version(current)
    except ValueError:
        # Development builds have no release identity and may update to a stable build.
        old = Version('0.0.0.dev0')
    return new > old and (not new.is_prerelease or old.is_prerelease)


def validate_download_url(value):
    if not isinstance(value, str) or len(value) > 2048:
        raise ValueError('下载地址无效')
    url = urlsplit(value)
    host = (url.hostname or '').lower()
    if (url.scheme != 'https' or url.username or url.password or url.fragment
            or not any(host == domain or host.endswith('.'+domain) for domain in ('gitcode.com', 'gitcode.net'))):
        raise ValueError('请填写 HTTPS 的 GitCode 发行版附件下载链接')
    if url.port not in (None, 443):
        raise ValueError('GitCode 下载地址端口无效')
    if 'access_token' in url.query.lower() or 'private_token' in url.query.lower():
        raise ValueError('请使用公开附件链接，不要把 GitCode 访问令牌分发到客户端')
    return value


def validate_release(data, product=None, target=None):
    if not isinstance(data, dict) or data.get('product') not in PRODUCTS or data.get('target') not in TARGETS:
        raise ValueError('更新软件或平台无效')
    if product is not None and data['product'] != product:
        raise ValueError('更新包属于另一款软件')
    if target is not None and data['target'] != target:
        raise ValueError('更新包与当前平台不匹配')
    parsed_version(data.get('version'))
    validate_download_url(data.get('url'))
    if not isinstance(data.get('sha256'), str) or not re.fullmatch('[0-9a-fA-F]{64}', data['sha256']):
        raise ValueError('请提供安装包 SHA-256 校验值')
    if type(data.get('size')) is not int or not 0 < data['size'] <= MAX_DOWNLOAD:
        raise ValueError('安装包大小无效（最多 4 GB）')
    if not isinstance(data.get('notes', ''), str) or len(data.get('notes', '')) > 2000:
        raise ValueError('更新说明过长')
    return {key: data[key] for key in ('product', 'target', 'version', 'url', 'sha256', 'size')} | {'notes': data.get('notes', '')}


def native_target():
    machine = platform.machine().lower()
    if sys.platform == 'win32' and machine in {'amd64', 'x86_64'}:
        return 'windows-x64'
    if sys.platform == 'darwin' and machine in {'arm64', 'aarch64'}:
        return 'macos-arm64'
    return ''


def build_info(product):
    if getattr(sys, 'frozen', False):
        try:
            data = json.loads((Path(sys._MEIPASS) / 'build_info.json').read_text(encoding='utf-8'))
            if data.get('product') == product and isinstance(data.get('version'), str):
                return data
        except (OSError, ValueError):
            pass
    return {'product': product, 'version': 'v0.0.0-dev', 'target': native_target()}


GITCODE_REPOSITORIES = {
    'char-detection-main': 'qq_28599947/hanzi-soft',
    'group-by-character': 'qq_28599947/hanzi-soft',
}
ASSET_PREFIXES = {'char-detection-main': '切字', 'group-by-character': '归并'}
UPDATE_MANIFEST = 'hanzi-update.json'


def manifest_digest(records):
    payload = json.dumps(records, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    return hashlib.sha256(payload).hexdigest()


def manifest_revisions(assets, name):
    pattern = re.compile(re.escape(name[:-5]) + r'-r([0-9]{8,20})-([0-9a-f]{64})\.json')
    found = []
    for asset in assets:
        if not isinstance(asset, dict) or asset.get('type') == 'source':
            continue
        match = pattern.fullmatch(asset.get('name', ''))
        if match:
            found.append((int(match[1]), match[2], asset))
    return sorted(found, key=lambda item: item[0], reverse=True)


def read_public_json(url, opener=None):
    """Read bounded public metadata; never attach an account-service token."""
    opener = opener or build_opener(HTTPSRedirects())
    request = Request(url, headers={'User-Agent': 'HanziDesktop-Updater/1', 'Accept': 'application/json'})
    with opener.open(request, timeout=15) as response:
        if urlsplit(response.geturl()).scheme != 'https':
            raise ValueError('更新信息地址未使用 HTTPS')
        payload = response.read(1024 * 1024 + 1)
    if len(payload) > 1024 * 1024:
        raise ValueError('更新信息过大')
    return json.loads(payload)


def check_gitcode_update(product, target, current_version, reader=read_public_json):
    if product not in GITCODE_REPOSITORIES or target not in TARGETS:
        raise ValueError('未知软件或平台')
    repository = GITCODE_REPOSITORIES[product]
    url = f'https://api.gitcode.com/api/v5/repos/{repository}/releases?per_page=100'
    try:
        releases = reader(url)
        if not isinstance(releases, list):
            raise ValueError('GitCode 发行版列表无效')
        candidates = []
        prefix = product + '-'
        for release in releases:
            tag = release.get('tag_name', '')
            if not tag.startswith(prefix) or release.get('draft') or release.get('prerelease'):
                continue
            version = tag[len(prefix):]
            try:
                parsed = parsed_version(version)
            except ValueError:
                continue
            if not parsed.is_prerelease:
                assets = release.get('assets')
                if not isinstance(assets, list):
                    raise ValueError('GitCode 附件信息无效')
                expected = f'{product}-{version}-{target}.zip'
                if any(isinstance(asset, dict) and asset.get('name') == expected
                       and asset.get('type') != 'source' for asset in assets):
                    candidates.append((parsed, release | {'tag_name': version}))
        if not candidates:
            return {'available': False, 'configured': False, 'message': 'GitCode 暂无当前平台的正式发行版。'}
        latest = max(candidates, key=lambda item: item[0])[1]
    except HTTPError as exc:
        if exc.code == 404:
            return {'available': False, 'configured': False, 'message': 'GitCode 暂无当前平台的正式发行版。'}
        raise
    if not isinstance(latest, dict):
        raise ValueError('GitCode 发行版信息无效')
    version = latest.get('tag_name')
    parsed_version(version)
    if latest.get('draft') or latest.get('prerelease') or not is_newer(version, current_version):
        return {'available': False, 'configured': True, 'latest_version': version}
    assets = latest.get('assets')
    if not isinstance(assets, list):
        raise ValueError('GitCode 附件信息无效')
    name = f'{product}-{version}-{target}.zip'
    matches = [a for a in assets if isinstance(a, dict) and a.get('name') == name and a.get('type') != 'source']
    if len(matches) != 1:
        return {'available': False, 'configured': False,
                'message': f'GitCode 最新版本 {version} 暂无当前平台的安装包。'}
    asset_url = validate_download_url(quote(matches[0].get('browser_download_url', ''), safe=':/?&=%+@'))
    notes = latest.get('body') or ''
    if not isinstance(notes, str):
        raise ValueError('GitCode 更新说明无效')
    platform_manifest = f'hanzi-update-{target}.json'
    revisions = manifest_revisions(assets, platform_manifest)
    manifests = [a for a in assets if isinstance(a, dict) and a.get('name') == platform_manifest and a.get('type') != 'source']
    if not manifests:
        manifests = [a for a in assets if isinstance(a, dict) and a.get('name') == UPDATE_MANIFEST and a.get('type') != 'source']
    if len(manifests) > 1:
        raise ValueError('更新清单重复')
    candidates = [(a, digest, True) for _, digest, a in revisions]
    candidates.extend((a, None, False) for a in manifests)
    if not candidates:
        return {'available': True, 'version': version, 'notes': notes[:2000], 'manual_url': asset_url}
    last_error = None
    for asset, digest, revised in candidates:
        try:
            manifest_url = validate_download_url(quote(asset.get('browser_download_url', ''), safe=':/?&=%+@'))
            records = reader(manifest_url)
            if not isinstance(records, list):
                raise ValueError('GitCode 更新清单无效')
            if digest and manifest_digest(records) != digest:
                raise ValueError('更新清单校验不符')
            matches = [r for r in records if isinstance(r, dict) and r.get('name') == name]
            if len(matches) != 1:
                raise ValueError('更新清单缺少当前平台的安装包信息')
            record = matches[0]
            if (record.get('version') != version or record.get('url') != asset_url
                    or record.get('product', product) != product or record.get('target', target) != target):
                raise ValueError('更新清单与 GitCode 发行版不一致')
            release = validate_release(record | {'product': product, 'target': target,
                'notes': record.get('notes', '') if revised else notes[:2000]}, product, target)
            return {'available': True, 'configured': True, 'release': release}
        except (OSError, ValueError) as exc:
            # An incomplete new upload must not make a previous valid revision unavailable.
            last_error = exc
    raise last_error


class Cancelled(Exception):
    pass


def check_cancel(cancel):
    if cancel.is_set():
        raise Cancelled('已取消')


class HTTPSRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if urlsplit(newurl).scheme != 'https':
            raise ValueError('下载重定向没有使用 HTTPS')
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def verify_file(path, release, cancel=None):
    cancel = cancel or Event()
    digest = hashlib.sha256()
    count = 0
    with Path(path).open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            check_cancel(cancel)
            count += len(chunk)
            if count > release['size']:
                raise ValueError('下载文件大小与发布记录不符')
            digest.update(chunk)
    if count != release['size'] or digest.hexdigest() != release['sha256'].lower():
        raise ValueError('安装包校验失败，请联系管理员核对发布文件')


def download_release(release, directory, cancel, progress=lambda done, total: None, opener=None):
    release = validate_release(release)
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    final = directory / f"{release['version']}-{release['target']}-{release['sha256'][:12]}.zip"
    fd, temporary = tempfile.mkstemp(prefix='.download-', suffix='.part', dir=directory)
    temp = Path(temporary)
    try:
        opener = opener or build_opener(HTTPSRedirects())
        # Only public download headers: auth-service session tokens never go to GitCode/CDN.
        request = Request(release['url'], headers={'User-Agent': 'HanziDesktop-Updater/1', 'Accept-Encoding': 'identity'})
        with os.fdopen(fd, 'wb') as out:
            check_cancel(cancel)
            with opener.open(request, timeout=20) as response:
                if urlsplit(response.geturl()).scheme != 'https':
                    raise ValueError('下载地址未使用 HTTPS')
                content_length = response.headers.get('Content-Length')
                if content_length and int(content_length) != release['size']:
                    raise ValueError('远端安装包大小与发布记录不符')
                count = 0
                while chunk := response.read(1024 * 1024):
                    check_cancel(cancel)
                    count += len(chunk)
                    if count > release['size']:
                        raise ValueError('远端文件超过发布大小')
                    out.write(chunk)
                    progress(count, release['size'])
        check_cancel(cancel)
        verify_file(temp, release, cancel)
        check_cancel(cancel)
        os.replace(temp, final)
        return final
    finally:
        temp.unlink(missing_ok=True)


def _member_name(info):
    name = info.filename
    if not info.flag_bits & 0x800:
        try:
            name = name.encode('cp437').decode('utf-8')
        except (UnicodeError, ValueError):
            pass
    path = PurePosixPath(name)
    if (not name or name.startswith('/') or '\\' in name or ':' in name or '\x00' in name
            or any(part in {'..', ''} or part.endswith((' ', '.')) for part in path.parts)):
        raise ValueError('安装包包含不安全路径')
    return path


def install_release(archive, release, directory, cancel, progress=lambda done, total: None):
    """Extract into a fresh directory and publish only after full validation.

    Nothing is written over the running app, annotations or user configuration.
    """
    release = validate_release(release)
    verify_file(archive, release, cancel)  # detect edits between download and install
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    stage = Path(tempfile.mkdtemp(prefix='.install-', dir=directory))
    published = False
    try:
        with zipfile.ZipFile(archive) as bundle:
            members = [(info, _member_name(info)) for info in bundle.infolist()]
            if not members or len(members) > 50000 or sum(info.file_size for info, _ in members) > MAX_UNPACKED:
                raise ValueError('安装包解压规模异常')
            names = [str(path).casefold() for _, path in members]
            if len(names) != len(set(names)):
                raise ValueError('安装包存在重复或大小写冲突路径')
            links = {path for info, path in members if stat.S_ISLNK(info.external_attr >> 16)}
            for info, path in members:
                if any(parent in links for parent in path.parents):
                    raise ValueError('安装包试图通过符号链接写入文件')
                if info.flag_bits & 1:
                    raise ValueError('不支持带密码的 ZIP 安装包')
                mode = info.external_attr >> 16
                if stat.S_IFMT(mode) not in {0, stat.S_IFREG, stat.S_IFDIR, stat.S_IFLNK}:
                    raise ValueError('安装包包含特殊文件')
            if release['target'] == 'windows-x64':
                reserved = {'CON', 'PRN', 'AUX', 'NUL'} | {f'{p}{n}' for p in ('COM', 'LPT') for n in range(1, 10)}
                if any(part.split('.')[0].upper() in reserved for _, path in members for part in path.parts):
                    raise ValueError('安装包包含 Windows 保留设备名')
            if links and release['target'] == 'windows-x64':
                raise ValueError('Windows 安装包不能包含符号链接')
            # Write regular files before links, so symlinks can never redirect writes.
            for index, (info, path) in enumerate(members):
                check_cancel(cancel)
                dest = stage.joinpath(*path.parts)
                if info.is_dir():
                    dest.mkdir(parents=True, exist_ok=True)
                elif path not in links:
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    with bundle.open(info) as source, dest.open('xb') as out:
                        while chunk := source.read(1024 * 1024):
                            check_cancel(cancel)
                            out.write(chunk)
                    dest.chmod(0o755 if (info.external_attr >> 16) & 0o111 else 0o644)
                progress(index + 1, len(members))
            for info, path in members:
                if path in links:
                    check_cancel(cancel)
                    if info.file_size > 4096:
                        raise ValueError('符号链接目标过长')
                    target = bundle.read(info).decode('utf-8')
                    if not target or '\\' in target or ':' in target or '\x00' in target or target.startswith('/'):
                        raise ValueError('符号链接目标无效')
                    dest = stage.joinpath(*path.parts)
                    dest.parent.mkdir(parents=True, exist_ok=True)
                    dest.symlink_to(target)
            # Resolve all chains after links exist; reject cycles and external targets.
            for path in links:
                try:
                    stage.joinpath(*path.parts).resolve().relative_to(stage.resolve())
                except (ValueError, RuntimeError) as exc:
                    raise ValueError('符号链接越过安装目录或形成循环') from exc
        check_cancel(cancel)
        if release['target'].startswith('macos-'):
            app_name = APP_NAMES[release['product']]
            candidates = [p for p in stage.rglob(app_name) if (p/'Contents/Info.plist').is_file()
                          and (p/'Contents/MacOS/launcher').is_file()]
        else:
            candidates = [p for p in stage.rglob(EXE_NAMES[release['product']]) if p.is_file() and not p.is_symlink()]
        if len(candidates) != 1:
            raise ValueError('安装包未包含唯一的目标软件')
        metadata_files = list(stage.rglob('build_info.json'))
        matched = False
        for metadata in metadata_files:
            if metadata.stat().st_size > 4096:
                raise ValueError('安装包版本信息异常')
            info = json.loads(metadata.read_text(encoding='utf-8'))
            if (info.get('product') != release['product']
                    or parsed_version(info.get('version')) != parsed_version(release['version'])):
                raise ValueError('安装包内部版本与发布记录不符')
            matched = matched or info.get('target') == release['target']
        if not matched:
            raise ValueError('安装包缺少与当前版本、平台匹配的构建信息，请重新打包')
        entry_relative = candidates[0].relative_to(stage)
        destination = directory / f"{release['version']}-{stage.name.removeprefix('.install-')}"
        check_cancel(cancel)
        os.replace(stage, destination)
        published = True
        return destination / entry_relative
    finally:
        if not published:
            shutil.rmtree(stage, ignore_errors=True)


def running_installation(product):
    """Return the installed bundle root, including the outer Mac app."""
    if not getattr(sys, 'frozen', False):
        return None
    executable = Path(sys.executable).resolve()
    if sys.platform == 'darwin':
        candidates = [p for p in executable.parents if p.name == APP_NAMES[product]]
        if candidates and '/AppTranslocation/' not in str(executable):
            return candidates[-1]
    elif sys.platform == 'win32' and executable.name == EXE_NAMES[product]:
        return executable.parent
    return None


def prepare_replacement(archive, release, current, cancel, progress=lambda done, total: None):
    """Stage on the installed volume; never modify the live installation."""
    current = Path(current)
    try:
        workspace = Path(tempfile.mkdtemp(prefix='.hanzi-update-', dir=current.parent))
    except OSError as exc:
        raise ValueError('当前软件目录不可写，请将软件移到个人可写目录后重试。') from exc
    try:
        entry = install_release(archive, release, workspace, cancel, progress)
        source = entry if release['target'].startswith('macos-') else entry.parent
        check_cancel(cancel)
        return source
    except BaseException:
        shutil.rmtree(workspace, ignore_errors=True)
        raise


def replacement_command(source, current, target, pid):
    """Native helper survives PyInstaller shutdown; all paths are literal data.

    Backup and staging stay beside the app for same-volume directory renames.
    On a failed second rename the original installation is restored.
    """
    import base64
    import shlex
    source, current = Path(source), Path(current)
    workspace = next(p for p in source.parents if p.name.startswith('.hanzi-update-'))
    backup = current.parent / (current.name + '.previous-' + workspace.name.removeprefix('.hanzi-update-'))
    if target.startswith('macos-'):
        script = workspace / 'apply.sh'
        script.write_text(f'''#!/bin/sh
exec >>{shlex.quote(str(workspace / 'update.log'))} 2>&1
n=0
while kill -0 {int(pid)} 2>/dev/null; do
  n=$((n + 1)); [ "$n" -lt 300 ] || exit 1
  sleep 1
done
/bin/mv {shlex.quote(str(current))} {shlex.quote(str(backup))} || exit 1
if ! /bin/mv {shlex.quote(str(source))} {shlex.quote(str(current))}; then
  /bin/mv {shlex.quote(str(backup))} {shlex.quote(str(current))}
  exit 1
fi
/usr/bin/open -n {shlex.quote(str(current))}
''', encoding='utf-8')
        return ['/bin/sh', str(script)]
    def literal(path):
        return "'" + str(path).replace("'", "''") + "'"
    # Directory.Move is literal and refuses to overwrite a pre-existing backup.
    matches = [name for name in EXE_NAMES.values() if (source / name).is_file()]
    if len(matches) != 1:
        raise ValueError('更新目录缺少唯一的软件入口')
    script = f'''
$ErrorActionPreference = 'Stop'
try {{
  $process = Get-Process -Id {int(pid)} -ErrorAction SilentlyContinue
  if ($process -and !$process.WaitForExit(300000)) {{ throw 'Application did not exit' }}
  # Copy local files after exit, so the last save is included.
  Get-ChildItem -LiteralPath {literal(current)} -Force | ForEach-Object {{
    $destination = Join-Path {literal(source)} $_.Name
    if ($_.Name -ne '_internal' -and !(Test-Path -LiteralPath $destination) -and
        !($_.Attributes -band [IO.FileAttributes]::ReparsePoint)) {{
      Copy-Item -LiteralPath $_.FullName -Destination $destination -Recurse -Force
    }}
  }}
  $moved = $false
  for ($attempt = 0; $attempt -lt 30; $attempt++) {{
    try {{ [IO.Directory]::Move({literal(current)}, {literal(backup)}); $moved = $true; break }}
    catch {{ Start-Sleep -Seconds 1 }}
  }}
  if (!$moved) {{ throw 'Application directory is still in use' }}
  try {{ [IO.Directory]::Move({literal(source)}, {literal(current)}) }}
  catch {{ [IO.Directory]::Move({literal(backup)}, {literal(current)}); throw }}
  Start-Process -FilePath {literal(current / matches[0])} -WorkingDirectory {literal(current)}
}} catch {{ $_ | Out-File -LiteralPath {literal(workspace / 'update.log')} -Encoding utf8; exit 1 }}
'''
    encoded = base64.b64encode(script.encode('utf-16-le')).decode('ascii')
    return ['powershell.exe', '-NoProfile', '-NonInteractive', '-EncodedCommand', encoded]


def relaunch_command(entry, target, pid):
    """Launch a separately installed bundle only after the old process exits."""
    import base64
    import shlex
    entry = Path(entry)
    workspace = Path(tempfile.mkdtemp(prefix='.hanzi-relaunch-', dir=entry.parent))
    if target.startswith('macos-'):
        script = workspace / 'launch.sh'
        script.write_text(f'''#!/bin/sh
exec >>{shlex.quote(str(workspace / 'update.log'))} 2>&1
n=0
while kill -0 {int(pid)} 2>/dev/null; do
  n=$((n + 1)); [ "$n" -lt 300 ] || exit 1
  sleep 1
done
/usr/bin/open -n {shlex.quote(str(entry))}
''', encoding='utf-8')
        return ['/bin/sh', str(script)]
    def literal(path):
        return "'" + str(path).replace("'", "''") + "'"
    script = f'''
$ErrorActionPreference = 'Stop'
try {{
  $process = Get-Process -Id {int(pid)} -ErrorAction SilentlyContinue
  if ($process -and !$process.WaitForExit(300000)) {{ throw 'Application did not exit' }}
  Start-Process -FilePath {literal(entry)} -WorkingDirectory {literal(entry.parent)}
}} catch {{ $_ | Out-File -LiteralPath {literal(workspace / 'update.log')} -Encoding utf8; exit 1 }}
'''
    return ['powershell.exe', '-NoProfile', '-NonInteractive', '-EncodedCommand',
            base64.b64encode(script.encode('utf-16-le')).decode('ascii')]
