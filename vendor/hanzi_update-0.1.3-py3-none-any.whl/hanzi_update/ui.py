"""Nonblocking desktop update UI shared by both products."""
import os
from pathlib import Path
import subprocess
import sys
import threading

from PySide6.QtCore import QObject, QTimer, Qt, Signal, Slot, QStandardPaths, QUrl
from PySide6.QtGui import QAction, QDesktopServices
from PySide6.QtWidgets import (QDialog, QLabel, QPushButton, QProgressBar, QVBoxLayout,
                              QHBoxLayout, QApplication, QTextBrowser, QSizePolicy)
from .core import (build_info, native_target, validate_release, is_newer,
                      download_release, install_release, Cancelled, check_gitcode_update,
                      running_installation, prepare_replacement, replacement_command)
from .core import relaunch_command


class Events(QObject):
    progress = Signal(object, object)
    complete = Signal(str, str)
    failed = Signal(str)
    checked = Signal(int, bool, object, bool)


class UpdateController(QObject):
    def __init__(self, window, product, *, is_locked=None):
        super().__init__(window)
        self.window = window
        self.is_locked = is_locked or (lambda: False)
        self.product = product
        self.info = build_info(self.product)
        self.target = native_target()
        self.dialog = None
        self.manual_url = None
        self.release = None
        self.archive = None
        self.installed = None
        self.busy = False
        self.checking = False
        self.check_requested = False
        self.check_started = False
        self.check_generation = 0
        self.current_install = running_installation(self.product)
        self.restart_requested = False
        self.cancel = threading.Event()
        self.events = Events(self)
        self.events.progress.connect(self.progress)
        self.events.complete.connect(self.completed)
        self.events.failed.connect(self.failed)
        self.events.checked.connect(self.checked_result)
        self.check_timer = QTimer(self)
        self.check_timer.setSingleShot(True)
        self.check_timer.timeout.connect(self.check_timed_out)
        self.action = QAction('检查更新…', window)
        self.action.triggered.connect(lambda: self.check(False))
        window.menuBar().addMenu('帮助').addAction(self.action)
        QApplication.instance().aboutToQuit.connect(self.cancel_work)
        QApplication.instance().aboutToQuit.connect(self.apply_on_exit)
        self.startup_timer = QTimer(self)
        self.startup_timer.setSingleShot(True)
        self.startup_timer.timeout.connect(lambda: self.check(True))
        self.startup_timer.start(3000)

    def cancel_work(self):
        self.cancel.set()

    def show_dialog(self):
        if self.dialog is None:
            self.dialog = QDialog(self.window)
            self.dialog.setWindowTitle('软件更新')
            self.dialog.setSizeGripEnabled(False)
            self.dialog.setAttribute(Qt.WA_DeleteOnClose, False)
            layout = QVBoxLayout(self.dialog)
            layout.setContentsMargins(20, 20, 20, 20)
            layout.setSpacing(12)
            self.title = QLabel(f"当前版本：{self.info['version']}  ·  {self.target or '不支持的平台'}")
            self.title.setTextFormat(Qt.PlainText)
            layout.addWidget(self.title)
            self.message = QLabel()
            self.message.setWordWrap(True)
            self.message.setTextFormat(Qt.PlainText)
            self.message.setAlignment(Qt.AlignLeft | Qt.AlignTop)
            self.message.setFixedHeight(self.message.fontMetrics().lineSpacing() * 2 + 4)
            self.message.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Fixed)
            layout.addWidget(self.message)
            self.notes = QTextBrowser()
            self.notes.setReadOnly(True)
            self.notes.setOpenExternalLinks(True)
            self.notes.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
            self.notes.setPlaceholderText('更新说明将在检查完成后显示。')
            self.notes.setAccessibleName('更新说明')
            self.notes.document().setDocumentMargin(12)
            self.notes.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Expanding)
            layout.addWidget(self.notes, 1)
            self.bar = QProgressBar()
            self.bar.setRange(0, 100)
            layout.addWidget(self.bar)
            row = QHBoxLayout()
            self.primary = QPushButton('下载并安装更新')
            self.primary.clicked.connect(self.perform)
            self.secondary = QPushButton('取消任务')
            self.secondary.clicked.connect(self.cancel_work)
            self.folder = QPushButton('打开所在目录')
            self.folder.clicked.connect(self.open_folder)
            row.addWidget(self.primary)
            row.addWidget(self.secondary)
            row.addWidget(self.folder)
            layout.addLayout(row)
            self.primary.setEnabled(False)
            self.secondary.setEnabled(False)
            self.folder.setEnabled(False)
        if not self.dialog.isVisible():
            screen = self.window.screen() or QApplication.primaryScreen()
            available = screen.availableGeometry()
            self.dialog.setFixedSize(min(640, available.width() - 32),
                                     min(520, available.height() - 64))
            self.dialog.show()
            frame = self.dialog.frameGeometry()
            center = (self.window.frameGeometry().center() if self.window.isVisible()
                      else available.center())
            frame.moveCenter(center)
            frame.moveLeft(max(available.left(), min(frame.left(), available.right() - frame.width() + 1)))
            frame.moveTop(max(available.top(), min(frame.top(), available.bottom() - frame.height() + 1)))
            self.dialog.move(frame.topLeft())
        self.dialog.show()
        self.dialog.raise_()

    def check(self, silent=False):
        if not silent:
            self.startup_timer.stop()
        elif self.check_started:
            return
        if self.installed:
            if not silent:
                self.show_dialog()
            return
        if self.busy or self.checking:
            if not silent:
                self.check_requested = True
                self.show_dialog()
                if self.checking:
                    self.message.setText('正在检查新版本…')
            return
        if self.is_locked():
            return
        if not self.target:
            if not silent:
                self.show_dialog()
                self.message.setText('当前平台暂无更新包。')
            return
        self.checking = True
        self.check_started = True
        self.check_generation += 1
        generation = self.check_generation
        self.check_timer.start(45000)
        self.check_requested = not silent
        self.manual_url = None
        self.release = self.archive = self.installed = None
        if not silent:
            self.show_dialog()
        if self.dialog is not None:
            self.primary.setEnabled(False)
            self.folder.setEnabled(False)
            self.notes.clear()
            self.message.setText('正在检查新版本…')
            self.bar.setRange(0, 0)
        product, target, version = self.product, self.target, self.info['version']
        events = self.events

        def work():
            try:
                result = check_gitcode_update(product, target, version)
                ok = True
            except Exception:
                result = {}
                ok = False
            try:
                events.checked.emit(generation, ok, result, silent)
            except RuntimeError:
                pass  # The window was closed while the public request was running.
        threading.Thread(target=work, name='hanzi-update-check', daemon=True).start()

    @Slot(int, bool, object, bool)
    def checked_result(self, generation, ok, data, silent):
        if generation != self.check_generation or not self.checking:
            return
        self.checked(ok, data, silent)

    def check_timed_out(self):
        self.check_generation += 1
        self.checked(False, {}, not self.check_requested)

    @Slot(bool, object, bool)
    def checked(self, ok, data, silent):
        self.check_timer.stop()
        silent = silent and not self.check_requested and self.dialog is None
        if self.dialog is not None:
            self.bar.setRange(0, 100)
            self.bar.setValue(0)
        self.checking = False
        if self.is_locked():
            return
        if not ok:
            if not silent:
                self.show_dialog()
                self.message.setText('无法连接 GitCode 或读取更新信息，请稍后重试。')
            return
        if not data.get('available'):
            if not silent:
                self.show_dialog()
                self.message.setText('当前已是最新版本。' if data.get('configured') else data.get('message', 'GitCode 暂无当前平台的更新包。'))
            return
        if data.get('manual_url'):
            self.manual_url = data['manual_url']
            self.show_dialog()
            self.message.setText(f"发现 {data['version']} · 此发行版需下载后手动安装。")
            self.notes.setMarkdown(data.get('notes') or '暂无更新说明。')
            self.primary.setText('前往下载')
            self.primary.setEnabled(True)
            self.folder.setEnabled(False)
            self.bar.setValue(0)
            return
        try:
            release = validate_release(data.get('release'), self.product, self.target)
            if not is_newer(release['version'], self.info['version']):
                raise ValueError('更新版本不高于当前版本')
        except ValueError as exc:
            if not silent:
                self.show_dialog()
                self.message.setText(str(exc))
            return
        self.release = release
        self.show_dialog()
        self.message.setText(f"发现 {release['version']}（{release['size']/1024/1024:.1f} MB）")
        self.notes.setMarkdown(release['notes'] or '暂无更新说明。')
        self.primary.setText('下载并安装更新')
        self.primary.setEnabled(True)
        self.folder.setEnabled(False)
        self.bar.setValue(0)

    def perform(self):
        if self.manual_url and not self.is_locked():
            QDesktopServices.openUrl(QUrl(self.manual_url))
            return
        if self.busy or not self.release or self.is_locked():
            return
        if self.installed:
            self.launch_installed()
            return
        self.busy = True
        self.cancel = threading.Event()
        self.primary.setEnabled(False)
        self.secondary.setEnabled(True)
        self.bar.setValue(0)
        mode = 'prepare'
        self.message.setText('正在下载、校验并准备更新…')
        release, archive, cancel, events = dict(self.release), self.archive, self.cancel, self.events
        base = Path(QStandardPaths.writableLocation(QStandardPaths.DownloadLocation) or str(Path.home()/'Downloads'))
        downloads = base/'汉字工具更新'/self.product
        installs = ((Path.home()/'Applications'/'HanziTools') if sys.platform == 'darwin' else
                    Path(os.environ.get('LOCALAPPDATA', str(Path.home()/'.local/share')))/'HanziTools') / self.product

        def emit(signal, *args):
            try:
                signal.emit(*args)
            except RuntimeError:
                cancel.set()  # application/window already destroyed

        def work():
            try:
                progress = lambda done, total: emit(events.progress, done, total)
                package = archive or download_release(release, downloads, cancel, progress)
                if self.current_install:
                    output = prepare_replacement(package, release, self.current_install, cancel, progress)
                else:
                    output = install_release(package, release, installs, cancel, progress)
                emit(events.complete, mode, str(output))
            except Cancelled:
                emit(events.failed, '已取消，原软件和当前工作保持不变。')
            except Exception as exc:
                # Network exceptions may include signed URLs; show a bounded user-facing error.
                message = str(exc) if isinstance(exc, ValueError) else '更新失败，请检查网络、磁盘空间或联系管理员。'
                emit(events.failed, message)
        # Files go into temporary directories; abrupt app exit cannot damage an installed app.
        threading.Thread(target=work, name='hanzi-update', daemon=True).start()

    def progress(self, done, total):
        self.bar.setValue(min(100, int(done * 100 / max(total, 1))))

    def completed(self, mode, path):
        self.busy = False
        self.secondary.setEnabled(False)
        self.primary.setEnabled(True)
        self.folder.setEnabled(True)
        self.bar.setValue(100)
        self.installed = Path(path)
        self.primary.setText('保存并重启更新')
        self.message.setText('正在保存并重启…')
        self.launch_installed()

    def failed(self, message):
        self.busy = False
        self.secondary.setEnabled(False)
        self.primary.setEnabled(bool(self.release))
        self.message.setText(message)

    def launch_installed(self):
        self.restart_requested = True
        self.window.close()  # Save guards must finish before aboutToQuit.

    def apply_on_exit(self):
        if not self.restart_requested or not self.installed:
            return
        import logging
        try:
            command = (replacement_command(self.installed, self.current_install, self.target, os.getpid())
                       if self.current_install else relaunch_command(self.installed, self.target, os.getpid()))
            options = {'start_new_session': True} if sys.platform != 'win32' else {
                'creationflags': subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP}
            subprocess.Popen(command, cwd=(self.current_install or self.installed).parent,
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL, **options)
        except Exception:
            logging.getLogger(__name__).exception('无法启动更新助手，原版本保持不变')

    def open_folder(self):
        path = self.installed or self.archive
        if path:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(path.parent)))
