"""Per-product distribution defaults and configurable platform validation."""
from .updates import TARGETS

DEFAULT_PLATFORMS = {
    'char-detection-main': ['windows-x64', 'macos-arm64', 'macos-x86_64'],
    'group-by-character': ['windows-x64', 'macos-arm64'],
}


def validate_platforms(product, targets):
    if (product not in DEFAULT_PLATFORMS or not isinstance(targets, list) or not targets
            or any(not isinstance(t, str) or t not in TARGETS for t in targets)
            or len(set(targets)) != len(targets)):
        raise ValueError('软件的分发平台配置无效')
    return [t for t in ('windows-x64', 'macos-arm64', 'macos-x86_64') if t in targets]


def repository_platforms(repo):
    return validate_platforms(repo['product'], repo.get('targets', DEFAULT_PLATFORMS[repo['product']]))
