"""Pure session policy, independent of Qt and the server libraries."""
from dataclasses import dataclass
import time
from ipaddress import ip_address
from urllib.parse import urlsplit


AUTH_SERVER_URL = "http://47.109.22.149:8675"


def server_url(value):
    value = value.strip().rstrip('/')
    if '://' not in value:
        host = urlsplit('//' + value).hostname
        value = ('http://' if is_loopback(host) or value == '47.109.22.149:8675' else 'https://') + value
    parsed = urlsplit(value)
    if (parsed.scheme not in {'http', 'https'} or not parsed.hostname
            or parsed.username or parsed.password or parsed.query or parsed.fragment
            or parsed.path not in {'', '/'}):
        raise ValueError('请输入 http://IP:端口 或 https://服务器地址')
    try:
        parsed.port
    except ValueError as exc:
        raise ValueError('端口无效') from exc
    if parsed.scheme == 'http' and not is_loopback(parsed.hostname) and value != AUTH_SERVER_URL:
        raise ValueError('该地址未配置通信公钥，请使用受支持的账号服务器。')
    return value


def uses_encrypted_channel(url):
    return url == AUTH_SERVER_URL


def is_loopback(host):
    # No DNS lookup: an arbitrary name can later resolve to a remote host.
    try:
        return ip_address(host).is_loopback
    except ValueError:
        return host == 'localhost'


@dataclass
class Session:
    url: str
    token: str
    username: str
    product: str
    expires_at: int
    last_ok: float
    check_interval: int = 60
    offline_grace: int = 300

    @classmethod
    def from_login(cls, url, product, data):
        if (data.get('product') != product or not isinstance(data.get('token'), str)
                or not 20 <= len(data['token']) <= 200
                or not isinstance(data.get('username'), str)
                or not isinstance(data.get('expires_at'), int)
                or data['expires_at'] <= time.time()):
            raise ValueError('服务器登录响应无效')
        return cls(url, data['token'], data['username'], product,
                   data['expires_at'], time.monotonic())

    def lock_reason(self, monotonic_now=None, wall_now=None):
        monotonic_now = time.monotonic() if monotonic_now is None else monotonic_now
        wall_now = time.time() if wall_now is None else wall_now
        if wall_now >= self.expires_at:
            return '登录或账号已到期，请重新登录。'
        if monotonic_now - self.last_ok >= self.offline_grace:
            return '超过 5 分钟未能验证授权，请检查网络并重新登录。'
        return ''
