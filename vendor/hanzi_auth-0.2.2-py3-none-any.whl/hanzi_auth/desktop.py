"""Qt network I/O is asynchronous; tokens stay in memory only."""
import json
import time

from PySide6.QtCore import QObject, QTimer, QUrl, QSettings, Qt, QEvent
from PySide6.QtGui import QShortcut
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkReply
from PySide6.QtWidgets import (
    QApplication, QDialog, QFormLayout, QLineEdit, QLabel, QPushButton,
    QVBoxLayout,
)
from .policy import Session, server_url, AUTH_SERVER_URL, uses_encrypted_channel
from .channel import seal_request
from .updates import build_info


class Transport(QObject):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.manager = QNetworkAccessManager(self)

    def request(self, url, path, callback, token='', body=None):
        url = server_url(url)
        exchange = None
        if uses_encrypted_channel(url):
            body, exchange = seal_request(path, body=body, token=token)
            path, token = '/api/secure', ''
        request = QNetworkRequest(QUrl(url + path))
        request.setTransferTimeout(8000)
        request.setAttribute(QNetworkRequest.RedirectPolicyAttribute, QNetworkRequest.ManualRedirectPolicy)
        request.setHeader(QNetworkRequest.ContentTypeHeader, 'application/json')
        if token:
            request.setRawHeader(b'Authorization', ('Bearer ' + token).encode())
        reply = (self.manager.get(request) if body is None else
                 self.manager.post(request, json.dumps(body).encode()))

        def finished():
            status = reply.attribute(QNetworkRequest.HttpStatusCodeAttribute) or 0
            valid = True
            try:
                data = json.loads(bytes(reply.readAll()))
                if not isinstance(data, dict):
                    raise ValueError()
                if exchange is not None:
                    status, data = exchange.open_response(data)
            except (ValueError, UnicodeError):
                valid = False
                status = 0
                data = {'detail': '服务响应校验失败或无法连接，请检查网络并更新软件。'}
            ok = valid and 200 <= status < 300 and reply.error() == QNetworkReply.NoError
            # Release the reply's closure before deferred deletion. A callback can
            # close the login dialog and destroy this reply's parent manager.
            reply.finished.disconnect(finished)
            reply.deleteLater()
            QTimer.singleShot(0, self, lambda: callback(ok, status, data))
        reply.finished.connect(finished)
        return reply


class LoginDialog(QDialog):
    def __init__(self, product, parent=None, url=None):
        super().__init__(parent)
        self.product = product
        self.session = None
        self.pending = False
        self.cancelled = False
        self.transport = Transport(self)
        self.settings = QSettings('HanziTools', 'Authentication')
        self.setWindowTitle('汉字工具 · 账号登录')
        self.setMinimumWidth(430)
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.server_url = url or AUTH_SERVER_URL
        self.username = QLineEdit(self.settings.value('username', ''))
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        form.addRow('账号', self.username)
        form.addRow('密码', self.password)
        layout.addLayout(form)
        self.message = QLabel()
        self.message.setWordWrap(True)
        layout.addWidget(self.message)
        self.message.hide()
        self.submit = QPushButton('登录')
        self.submit.clicked.connect(self.login)
        self.password.returnPressed.connect(self.login)
        layout.addWidget(self.submit)

    def login(self):
        if self.pending:
            return
        self.message.show()
        try:
            url = server_url(self.server_url)
        except ValueError as exc:
            self.message.setText(str(exc))
            return
        if not self.username.text().strip() or not self.password.text():
            self.message.setText('请输入账号和密码。')
            return
        self.pending = True
        for widget in (self.submit, self.username, self.password):
            widget.setEnabled(False)
        self.message.setText('正在验证…')
        self.transport.request(url, '/api/login', lambda ok, status, data: self.result_ready(url, ok, data),
                               body={'username': self.username.text().strip(),
                                     'password': self.password.text(), 'product': self.product,
                                     'client_version': build_info(self.product)['version']})

    def result_ready(self, url, ok, data):
        if self.cancelled:
            return
        self.pending = False
        self.message.show()
        for widget in (self.submit, self.username, self.password):
            widget.setEnabled(True)
        if ok:
            try:
                self.session = Session.from_login(url, self.product, data)
            except ValueError as exc:
                self.message.setText(str(exc))
                return
            self.settings.setValue('username', self.session.username)
            self.password.clear()
            self.accept()
        else:
            detail = data.get('detail')
            self.message.setText(detail if isinstance(detail, str) else '登录失败，请检查输入。')

    def reject(self):
        # Deleting the transport cancels requests without late successful login.
        self.cancelled = True
        self.transport.deleteLater()
        self.password.clear()
        super().reject()


class LockDialog(QDialog):
    def reject(self):
        # Keep the recovery controls reachable until login succeeds or app exits.
        pass


class SessionGuard(QObject):
    def __init__(self, window, session, save_callback, lock_callback=None):
        super().__init__(window)
        self.window = window
        self.session = session
        self.save_callback = save_callback
        self.lock_callback = lock_callback
        self.locked = False
        self.inflight = False
        self.next_check = time.monotonic() + session.check_interval
        self.transport = Transport(self)
        self.timer = QTimer(self)
        self.timer.setInterval(1000)
        self.timer.timeout.connect(self.tick)
        self.timer.start()
        QApplication.instance().installEventFilter(self)

    def eventFilter(self, watched, event):
        # Workers may re-enable shortcuts after completion; intercept dispatch too.
        if event.type() == QEvent.Shortcut and getattr(self, 'locked', False) and isinstance(watched, QShortcut):
            return True
        return False

    def tick(self):
        if self.locked:
            return
        reason = self.session.lock_reason()
        if reason:
            self.lock(reason)
            return
        if not self.inflight and time.monotonic() >= self.next_check:
            self.inflight = True
            self.transport.request(self.session.url, '/api/session', self.checked, self.session.token)

    def checked(self, ok, status, data):
        self.inflight = False
        if self.locked:
            return
        self.next_check = time.monotonic() + self.session.check_interval
        if ok:
            if (data.get('username') != self.session.username or data.get('product') != self.session.product
                    or not isinstance(data.get('expires_at'), int)):
                self.lock('授权响应无效，请重新登录。')
                return
            self.session.last_ok = time.monotonic()
            self.session.expires_at = data['expires_at']
        elif status in (401, 403):
            self.lock('账号已停用、权限已更改或登录已失效。')
        else:
            self.next_check = time.monotonic() + 10

    def lock(self, reason):
        if self.locked:
            return
        self.locked = True
        if self.lock_callback:
            self.lock_callback()
        self.central_was_enabled = self.window.centralWidget().isEnabled()
        self.window.centralWidget().setEnabled(False)
        self.shortcuts = [(s, s.isEnabled()) for s in self.window.findChildren(QShortcut)]
        for shortcut, _ in self.shortcuts:
            shortcut.setEnabled(False)
        self.dialog = LockDialog(self.window)
        self.dialog.setWindowTitle('使用权限已暂停')
        self.dialog.setWindowModality(Qt.ApplicationModal)
        self.dialog.setMinimumWidth(420)
        layout = QVBoxLayout(self.dialog)
        label = QLabel(reason + '\n当前工作仍保留。可以保存当前成果，或重新登录。')
        label.setWordWrap(True)
        layout.addWidget(label)
        save = QPushButton('保存当前页' if self.session.product == 'char-detection-main' else '保存复核结果')
        save.clicked.connect(self.save_callback)
        retry = QPushButton('重新登录')
        retry.clicked.connect(self.relogin)
        layout.addWidget(save)
        layout.addWidget(retry)
        exit_button = QPushButton('退出软件')
        exit_button.clicked.connect(self.exit_window)
        layout.addWidget(exit_button)
        self.dialog.show()

    def exit_window(self):
        self.dialog.hide()
        if not self.window.close():
            self.dialog.show()

    def relogin(self):
        login = LoginDialog(self.session.product, self.dialog, url=self.session.url)
        if login.exec():
            self.session = login.session
            self.locked = False
            self.window.centralWidget().setEnabled(self.central_was_enabled)
            for shortcut, enabled in self.shortcuts:
                shortcut.setEnabled(enabled)
            self.dialog.accept()
            self.dialog.deleteLater()
            self.next_check = time.monotonic() + self.session.check_interval
