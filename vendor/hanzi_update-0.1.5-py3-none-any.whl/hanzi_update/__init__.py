"""Shared native updater entry point, independent of authentication.

The host owns unsaved-work handling; native engines own signed updates.
Legacy core/ui APIs remain available for compatibility with previous releases.
"""


def attach_updates(window, product, *, button=None, is_locked=None, precheck=None):
    from .core import PRODUCTS
    if product not in PRODUCTS:
        raise ValueError('未知软件')
    controller = getattr(window, '_update_controller', None)
    if controller is None:
        from .native_ui import NativeUpdateController as UpdateController
        controller = UpdateController(window, product, is_locked=is_locked, precheck=precheck)
        window._update_controller = controller
    elif controller.product != product:
        raise ValueError('此窗口已接入另一款软件的更新')
    if button is not None and not button.property('hanziUpdateConnected'):
        button.clicked.connect(controller.action.trigger)
        button.setProperty('hanziUpdateConnected', True)
    return controller


__version__ = "0.1.5"
