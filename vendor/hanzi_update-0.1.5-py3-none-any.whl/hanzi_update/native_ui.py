"""Qt lifecycle adapter for native update engines."""
import json
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
import sys
import threading

from PySide6.QtCore import QObject, QTimer, Signal, Qt, QEvent, QStandardPaths
from PySide6.QtGui import QAction
from PySide6.QtWidgets import QApplication, QMessageBox
from .backends import create_updater
from .backends.base import UpdateConfig
from .core import build_info


class NativeUpdateController(QObject):
    preparation_requested = Signal()
    shutdown_requested = Signal()

    def __init__(self, window, product, *, is_locked=None):
        super().__init__(window)
        self.window, self.product = window, product
        self.is_locked = is_locked or (lambda: False)
        self.restart_requested = False
        self.backend = None
        self.error = '此构建未配置原生更新，请安装正式发行版。'
        self.preparing = False
        self.ready = threading.Event()
        self.state_lock = threading.Lock()
        self.approved = False
        self.stopping = False
        self.logger = logging.getLogger('hanzi_update.native.' + product)
        self.logger.setLevel(logging.INFO)
        try:
            directory = Path(QStandardPaths.writableLocation(QStandardPaths.AppLocalDataLocation)) / 'logs'
            directory.mkdir(parents=True, exist_ok=True)
            if not self.logger.handlers:
                handler = RotatingFileHandler(directory / 'update.log', maxBytes=262144, backupCount=2, encoding='utf-8')
                self.logger.addHandler(handler)
        except OSError:
            pass  # Logging must not prevent startup.
        self.preparation_requested.connect(self.prepare_close, Qt.QueuedConnection)
        self.shutdown_requested.connect(self.finish_close, Qt.QueuedConnection)
        window.installEventFilter(self)
        self.action = QAction('检查更新…', window)
        self.action.triggered.connect(lambda: self.check(False))
        window.menuBar().addMenu('帮助').addAction(self.action)
        QApplication.instance().aboutToQuit.connect(self.shutdown)
        self.startup_timer = QTimer(self)
        self.startup_timer.setSingleShot(True)
        self.startup_timer.timeout.connect(self.initialize)
        self.startup_timer.start(3000)
        self.preparation_timer = QTimer(self)
        self.preparation_timer.timeout.connect(self.poll_preparation)

    def initialize(self):
        if self.backend or self.stopping:
            return
        try:
            if not getattr(sys, 'frozen', False):
                return
            info = build_info(self.product)
            data = json.loads((Path(sys._MEIPASS) / 'native_update.json').read_text(encoding='utf-8'))
            config = UpdateConfig(**data)
            if config.product != self.product or config.version != info['version']:
                raise ValueError('更新配置与构建版本不匹配')
            location = Path(sys.executable).resolve().parent
            if sys.platform == 'darwin':
                bundles = [p for p in Path(sys.executable).resolve().parents if p.suffix == '.app']
                if not bundles:
                    raise ValueError('找不到产品 app')
                location = bundles[-1]
                import plistlib
                plist = plistlib.loads((location / 'Contents/Info.plist').read_bytes())
                if (plist.get('SUFeedURL') != config.feed_url or plist.get('SUPublicEDKey') != config.public_key
                        or plist.get('CFBundleVersion') != config.build_version):
                    raise ValueError('Sparkle bundle 配置不匹配')
            candidate = create_updater(config, location, prepare=self.request_prepare,
                                       shutdown=self.shutdown_requested.emit, event=self.logger.info)
            candidate.initialize()
            self.backend = candidate
            self.logger.info('current_version=%s feed_url=%s', config.version, config.feed_url)
        except Exception as exc:
            self.error = '原生更新暂不可用，请联系发布者检查配置或安装包。'
            self.logger.warning('update_error initialization %s', type(exc).__name__)

    def check(self, silent=False):
        if self.is_locked() or self.stopping:
            return
        self.initialize()
        if self.preparing:
            self.prepare_close()
        elif self.backend:
            self.backend.check_for_updates()
        elif not silent:
            QMessageBox.information(self.window, '软件更新', self.error)

    def request_prepare(self):
        # WinSparkle invokes from a worker; Sparkle invokes on the main thread.
        with self.state_lock:
            if self.stopping:
                return 0
            self.ready.clear()
            self.approved = False
            self.preparation_requested.emit()
        if sys.platform == 'win32':
            return int(self.ready.wait() and self.approved and not self.stopping)

    def prepare_close(self):
        if self.stopping or self.is_locked():
            self.ready.set()
            return
        self.preparing = True
        self.preparation_timer.start(100)
        self.restart_requested = True
        self.window.close()

    def eventFilter(self, watched, event):
        if watched is self.window and event.type() == QEvent.Close and self.preparing:
            # Probe the host's save/worker policy without actually quitting before
            # the native installer has been authorized. Async saves may retry close.
            self.window.closeEvent(event)
            if event.isAccepted():
                self.approved = True
                self.preparing = False
                self.preparation_timer.stop()
                self.ready.set()
                if self.backend and hasattr(self.backend, 'resume_installation'):
                    QTimer.singleShot(0, self.backend.resume_installation)
            elif not self.restart_requested:
                self.preparing = False
                self.preparation_timer.stop()
                self.ready.set()
            event.ignore()
            return True
        return super().eventFilter(watched, event)

    def poll_preparation(self):
        if self.preparing and not self.restart_requested:
            self.preparing = False
            self.preparation_timer.stop()
            self.ready.set()

    def finish_close(self):
        if self.approved:
            self.preparing = False
            self.window.close()

    def shutdown(self):
        with self.state_lock:
            self.stopping = True
            self.ready.set()  # Release native workers before cleanup joins them.
        self.startup_timer.stop()
        self.preparation_timer.stop()
        if self.backend:
            self.backend.shutdown()
