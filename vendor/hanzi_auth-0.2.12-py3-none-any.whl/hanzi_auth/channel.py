"""Authenticated, encrypted desktop messages using libsodium's public-key Box.

The server public key is shipped with the application, never fetched over HTTP.
Each request gets a fresh client key and ID. Both directions are encrypted and
direction-tagged; the server additionally records request IDs to reject replay.
"""
import base64
from dataclasses import dataclass
import json
import secrets
import time

from nacl.exceptions import CryptoError
from nacl.public import Box, PrivateKey, PublicKey

SERVER_PUBLIC_KEY = '3+9guL0PQFk0NA/nhY24zGOjFj7x9wkZn7c1FKJCgWM='
PROTOCOL = 'hanzi-auth-box-v1'
CLOCK_SKEW = 300


def encode(value):
    return base64.b64encode(value).decode('ascii')


def decode(value, maximum=65536):
    if not isinstance(value, str) or len(value) > maximum:
        raise ValueError('Invalid encrypted message')
    return base64.b64decode(value, validate=True)


def pack(data):
    return json.dumps(data, separators=(',', ':'), ensure_ascii=True).encode()


@dataclass
class Exchange:
    box: Box
    request_id: str
    used: bool = False

    def open_response(self, envelope):
        try:
            if self.used or envelope.get('protocol') != PROTOCOL:
                raise ValueError()
            data = json.loads(self.box.decrypt(decode(envelope['payload'])))
            if (data.get('type') != 'response' or data.get('id') != self.request_id
                    or type(data.get('status')) is not int
                    or not 200 <= data['status'] <= 599
                    or not isinstance(data.get('data'), dict)):
                raise ValueError()
            self.used = True
            return data['status'], data['data']
        except (ValueError, KeyError, TypeError, AttributeError, CryptoError) as exc:
            raise ValueError('服务器响应校验失败，请检查网络或更新软件。') from exc


def seal_request(path, *, body=None, token='', public_key=SERVER_PUBLIC_KEY):
    private = PrivateKey.generate()
    exchange = Exchange(Box(private, PublicKey(decode(public_key, 64))), secrets.token_hex(16))
    data = {'type': 'request', 'id': exchange.request_id, 'at': int(time.time()),
            'path': path, 'method': 'GET' if body is None else 'POST',
            'token': token, 'body': body}
    envelope = {'protocol': PROTOCOL, 'client_key': encode(bytes(private.public_key)),
                'payload': encode(exchange.box.encrypt(pack(data)))}
    return envelope, exchange


def open_request(envelope, private_key):
    try:
        if envelope.get('protocol') != PROTOCOL:
            raise ValueError()
        client_key = decode(envelope['client_key'], 64)
        box = Box(private_key, PublicKey(client_key))
        data = json.loads(box.decrypt(decode(envelope['payload'], 12000)))
        request_id = data.get('id')
        if (data.get('type') != 'request' or not isinstance(request_id, str)
                or len(request_id) != 32 or any(c not in '0123456789abcdef' for c in request_id)
                or type(data.get('at')) is not int
                or abs(time.time() - data['at']) > CLOCK_SKEW
                or not isinstance(data.get('token'), str) or len(data['token']) > 200
                or any(c not in 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-' for c in data['token'])
                or not (data.get('body') is None or isinstance(data['body'], dict))):
            raise ValueError()
        return data, Exchange(box, request_id), encode(client_key) + ':' + request_id
    except (ValueError, KeyError, TypeError, AttributeError, CryptoError) as exc:
        raise ValueError('加密请求无效或已过期。') from exc


def seal_response(exchange, status, data):
    payload = {'type': 'response', 'id': exchange.request_id, 'status': status, 'data': data}
    return {'protocol': PROTOCOL, 'payload': encode(exchange.box.encrypt(pack(payload)))}
