"""Remember verified passwords in the application's local user data directory."""
import hashlib
import os
from pathlib import Path
import sys
import tempfile

from nacl.secret import SecretBox
from nacl.exceptions import CryptoError
from nacl.utils import random

from .policy import server_url


def data_directory():
    if sys.platform == 'darwin':
        base = Path.home() / 'Library' / 'Application Support'
    elif sys.platform == 'win32':
        base = Path(os.environ.get('LOCALAPPDATA') or Path.home() / 'AppData' / 'Local')
    else:
        base = Path(os.environ.get('XDG_DATA_HOME') or Path.home() / '.local' / 'share')
    return base / 'HanziTools' / 'credentials'


class CredentialStore:
    def __init__(self, url, directory=None):
        identity = hashlib.sha256(server_url(url).encode()).hexdigest()
        self.service = 'HanziTools.Authentication.' + identity
        self.directory = (Path(directory) if directory is not None else data_directory()) / identity

    def path(self, username):
        return self.directory / (hashlib.sha256(username.encode()).hexdigest() + '.bin')

    def box(self, create=False):
        key_path = self.directory / '.key'
        if create:
            self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
            # Publish a fully written key atomically; concurrent clients reuse the winner.
            fd, temporary = tempfile.mkstemp(prefix='.key-', dir=self.directory)
            try:
                with os.fdopen(fd, 'wb') as stream:
                    stream.write(random(SecretBox.KEY_SIZE))
                try:
                    os.link(temporary, key_path)
                except FileExistsError:
                    pass
            finally:
                Path(temporary).unlink(missing_ok=True)
        return SecretBox(key_path.read_bytes())

    def get(self, username):
        try:
            payload = self.path(username).read_bytes()
            return self.box().decrypt(payload).decode('utf-8')
        except (FileNotFoundError, ValueError, UnicodeError, CryptoError):
            return ''

    def set(self, username, password):
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        payload = self.box(create=True).encrypt(password.encode('utf-8'))
        fd, temporary = tempfile.mkstemp(prefix='.password-', dir=self.directory)
        try:
            with os.fdopen(fd, 'wb') as stream:
                stream.write(payload)
            os.replace(temporary, self.path(username))
        finally:
            Path(temporary).unlink(missing_ok=True)

    def delete(self, username):
        self.path(username).unlink(missing_ok=True)
