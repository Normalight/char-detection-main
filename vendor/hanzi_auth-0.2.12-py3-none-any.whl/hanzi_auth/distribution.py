"""Per-product distribution defaults and configurable platform validation.

The product set, display labels and per-product platforms all derive from the
registry shipped inside the hanzi-update package (products.json), so adding a
product there updates this service without editing per-module constants.
"""
from .updates import PRODUCT_TARGETS

DEFAULT_PLATFORMS = {product: list(targets) for product, targets in PRODUCT_TARGETS.items()}


def validate_platforms(product, targets):
    allowed = PRODUCT_TARGETS.get(product, ())
    if (product not in DEFAULT_PLATFORMS or not isinstance(targets, list) or not targets
            or any(not isinstance(t, str) or t not in allowed for t in targets)
            or len(set(targets)) != len(targets)):
        raise ValueError('软件的分发平台配置无效')
    return [t for t in allowed if t in targets]


def repository_platforms(repo):
    return validate_platforms(repo['product'], repo.get('targets', DEFAULT_PLATFORMS[repo['product']]))
