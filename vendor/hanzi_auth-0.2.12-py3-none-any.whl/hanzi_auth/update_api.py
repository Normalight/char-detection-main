"""Administrative release registration and authenticated update discovery."""
import json
import time
import xml.etree.ElementTree as ET
import httpx
from fastapi import Depends, HTTPException, Query
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, Field
from .distribution import DEFAULT_PLATFORMS
from .updates import PRODUCTS, TARGETS, is_newer, validate_release, validate_download_url


class ReleaseInput(BaseModel):
    version: str = Field(min_length=1, max_length=64)
    url: str = Field(min_length=1, max_length=2048)
    sha256: str = Field(min_length=64, max_length=64)
    size: int = Field(gt=0, le=4 * 1024**3)
    notes: str = Field(default='', max_length=2000)
    enabled: bool = True


class NativeCheckInput(BaseModel):
    product: str = Field(min_length=1, max_length=64)
    target: str = Field(min_length=1, max_length=32)
    version: str = Field(min_length=1, max_length=64)


SPARKLE_NS = 'http://www.andymatuschak.org/xml-namespaces/sparkle'
NATIVE_FEED_BASE = 'https://gitcode.com/qq_28599947/hanzi-soft/releases/download/'


def native_feed_ready(product, target, release, client_factory=None):
    """A precheck is positive only when the public signed feed serves this installer."""
    name = {'windows-x64': 'windows-appcast.xml', 'macos-arm64': 'macos-appcast.xml',
            'macos-x86_64': 'macos-x86_64-appcast.xml'}[target]
    url = NATIVE_FEED_BASE + product + '-stable/' + name
    try:
        factory = client_factory or httpx.Client
        with factory(trust_env=False, follow_redirects=True,
                     timeout=httpx.Timeout(8, connect=4)) as client:
            with client.stream('GET', url) as response:
                if response.status_code != 200 or response.url.scheme != 'https':
                    return False
                chunks, size = [], 0
                for chunk in response.iter_bytes(65536):
                    size += len(chunk)
                    if size > 1024 * 1024:
                        return False
                    chunks.append(chunk)
        items = ET.fromstring(b''.join(chunks)).findall('.//item')
        if len(items) != 1:
            return False
        item = items[0]
        enclosure = item.find('enclosure')
        version = (item.findtext(f'{{{SPARKLE_NS}}}shortVersionString') or
                   (enclosure.get(f'{{{SPARKLE_NS}}}shortVersionString') if enclosure is not None else None))
        return bool(enclosure is not None and version == release['version'].removeprefix('v')
                    and enclosure.get('url') == validate_download_url(release['url'])
                    and enclosure.get('length') == str(release['size'])
                    and enclosure.get(f'{{{SPARKLE_NS}}}edSignature'))
    except (httpx.HTTPError, ET.ParseError, ValueError, KeyError):
        return False


def add_routes(app, store, current, administrator, mirror=None):
    def platforms(product):
        return mirror.targets_for(product) if mirror else DEFAULT_PLATFORMS.get(product, [])
    def download_products(session):
        row = session[0]
        if row['product'] not in {'portal', 'admin'}:
            raise HTTPException(403, '请登录下载平台')
        return PRODUCTS if row['admin'] else set(json.loads(row['products']))

    @app.get('/api/downloads')
    def downloads(session=Depends(current)):
        permitted = download_products(session)
        with store.connect() as db:
            rows = db.execute('SELECT * FROM releases WHERE enabled=1 ORDER BY product,target').fetchall()
        items = []
        for product in sorted(permitted):
            packages = []
            for row in rows:
                if row['product'] != product or row['target'] not in platforms(product):
                    continue
                release = json.loads(row['metadata'])
                packages.append({key: release.get(key, '') for key in ('target', 'version', 'size', 'notes', 'sha256')} |
                                {'download_path': '/api/downloads/' + product + '/' + row['target'],
                                 'published_at': row['published_at']})
            items.append({'product': product, 'packages': packages})
        return items

    @app.get('/api/downloads/{product}/{target}')
    def download(product: str, target: str, session=Depends(current)):
        permitted = download_products(session)
        if product not in permitted:
            raise HTTPException(403, '此账号未获授权下载该软件')
        if target not in platforms(product):
            raise HTTPException(404, '安装包不存在')
        with store.connect() as db:
            row = db.execute('SELECT metadata FROM releases WHERE product=? AND target=? AND enabled=1',
                             (product, target)).fetchone()
        if row is None:
            raise HTTPException(404, '此平台暂无可下载的安装包')
        try:
            url = validate_download_url(json.loads(row['metadata'])['url'])
        except (ValueError, KeyError):
            raise HTTPException(503, '安装包地址暂不可用')
        return RedirectResponse(url, status_code=302, headers={'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer'})

    @app.get('/api/admin/updates')
    def list_updates(admin=Depends(administrator)):
        with store.connect() as db:
            return [json.loads(row['metadata']) | {'enabled': bool(row['enabled']), 'published_at': row['published_at']}
                    for row in db.execute('SELECT * FROM releases ORDER BY product, target')
                    if row['target'] in platforms(row['product'])]

    @app.put('/api/admin/updates/{product}/{target}')
    def register(product: str, target: str, body: ReleaseInput, admin=Depends(administrator)):
        try:
            if target not in platforms(product):
                raise ValueError('该软件未启用此分发平台')
            release = validate_release(body.model_dump() | {'product': product, 'target': target})
        except ValueError as exc:
            raise HTTPException(422, str(exc))
        with store.connect() as db:
            db.execute('''INSERT INTO releases VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(product, target) DO UPDATE SET metadata=excluded.metadata,
                enabled=excluded.enabled, published_at=excluded.published_at''',
                (product, target, json.dumps(release), int(body.enabled), int(time.time())))
            db.execute("INSERT INTO audit VALUES (?, ?, 'publish_update', ?)",
                       (int(time.time()), admin['username'], product + '/' + target + '/' + body.version))
        return {'ok': True}

    @app.get('/api/updates/{product}/{target}')
    def check(product: str, target: str, version: str = Query(default='v0.0.0-dev', max_length=64),
              session=Depends(current)):
        if product not in PRODUCTS or target not in platforms(product):
            raise HTTPException(400, '未知软件或平台')
        if session[0]['product'] != product:
            raise HTTPException(403, '请使用对应软件的登录会话检查更新')
        with store.connect() as db:
            row = db.execute('SELECT * FROM releases WHERE product=? AND target=? AND enabled=1',
                             (product, target)).fetchone()
        if row is None:
            return {'available': False, 'configured': False}
        release = json.loads(row['metadata'])
        if not is_newer(release['version'], version):
            return {'available': False, 'configured': True, 'latest_version': release['version']}
        return {'available': True, 'configured': True, 'release': release}

    @app.post('/api/native-update-check')
    def native_check(body: NativeCheckInput, session=Depends(current)):
        if body.product not in PRODUCTS or body.target not in platforms(body.product):
            raise HTTPException(400, '未知软件或平台')
        if session[0]['product'] != body.product:
            raise HTTPException(403, '请使用对应软件的登录会话检查更新')
        with store.connect() as db:
            row = db.execute('SELECT metadata FROM releases WHERE product=? AND target=? AND enabled=1',
                             (body.product, body.target)).fetchone()
        if row is None:
            return {'available': False, 'configured': False}
        release = json.loads(row['metadata'])
        if not is_newer(release['version'], body.version):
            return {'available': False, 'configured': True, 'latest_version': release['version']}
        if not native_feed_ready(body.product, body.target, release):
            return {'available': False, 'configured': True, 'pending': True,
                    'latest_version': release['version']}
        return {'available': True, 'configured': True, 'latest_version': release['version']}
