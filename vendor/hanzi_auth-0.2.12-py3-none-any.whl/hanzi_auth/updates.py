"""Compatibility import for the independent hanzi-update package."""
import sys
from hanzi_update import core as _module

sys.modules[__name__] = _module
