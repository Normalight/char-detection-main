"""Shared authentication; Qt and server dependencies load only when needed."""
__version__ = "0.2.11"


def require_login(product):
    from .desktop import LoginDialog
    dialog = LoginDialog(product)
    return dialog.session if dialog.exec() else None


def start_session(app, product):
    """Own the process instance before showing the shared login dialog."""
    from .single_instance import acquire_instance
    if acquire_instance(app, product) is None:
        return None
    return require_login(product)


def is_locked(window):
    """Application callbacks use this API without inspecting auth internals."""
    return bool(getattr(getattr(window, '_auth_guard', None), 'locked', False))


def protect_window(window, session, save_callback, lock_callback=None, *, update_button=None):
    from .desktop import SessionGuard
    guard = SessionGuard(window, session, save_callback, lock_callback)
    window._auth_guard = guard
    from PySide6.QtWidgets import QApplication
    instance = getattr(QApplication.instance(), '_hanzi_instance', None)
    if instance is not None:
        instance.window = window
    if update_button is not None:
        from hanzi_update import attach_updates
        attach_updates(window, session.product, button=update_button,
                       is_locked=lambda: guard.locked, precheck=guard.check_native_update)
    return guard
